init python:
    # 아이템 클래스 정의
    class Item:
        def __init__(self, name="", description="", uid=0):
            self.name = name
            self.description = description
            self.uid = uid
    
    # 인벤토리 클래스
    class Inventory:
        def __init__(self):
            self.items = {}
            self.max_slots = 20
        
        def add_item(self, item, quantity=1):
            """아이템을 인벤토리에 추가"""
            if item.name in self.items:
                self.items[item.name]["quantity"] += quantity
            else:
                self.items[item.name] = {
                    "item": item,
                    "quantity": quantity
                }
            return True
        
        def remove_item(self, item_name, quantity=1):
            """아이템을 인벤토리에서 제거"""
            if item_name in self.items:
                self.items[item_name]["quantity"] -= quantity
                if self.items[item_name]["quantity"] <= 0:
                    del self.items[item_name]
                return True
            return False
        
        def has_item(self, item_name):
            """아이템 보유 여부 확인"""
            return item_name in self.items and self.items[item_name]["quantity"] > 0
        
        def get_quantity(self, item_name):
            """특정 아이템의 수량 반환"""
            if item_name in self.items:
                return self.items[item_name]["quantity"]
            return 0

        def get_all_items(self):
            """모든 아이템 목록 반환"""
            return list(self.items.values())

# 전역 인벤토리 인스턴스
default inventory = Inventory()
default current_item = Item()
default item_name = ""
default inventory_open = False
default inventory_toggleable = False

# 아이템 정의
init python:
    # 예시 아이템들
    badge = Item("Attornye's Badge", "No one would believe I was a defense attorney if I didn't carry this.", 6)
    autopsy = Item("Cindy's Autopsy Report", "Time of death: 7/31, 4PM - 5PM Cause of death: loss of blood due to blunt trauma.", 10)
    thinker = Item("Statue", "A statue in the shape of \"The Thinker.\" It's rather heavy.", 11)
    passport = Item("Passport", "The victim apparently arrived home from Paris on 7/30, the day before the murder.", 12)
    borecord = Item("Blackout Record", "Electricity to Ms. Stone's building was out from noon to 6PM on the day of the crime.", 13)
    # 예시 프로필들
    interview = [
    Item("사망자 정보", "이름: 앤더슨 브랜트\n나이: 34살\nKNN 아나운서 3년차", 0),
    Item("가족의 과거력", "할머니, 동생\n어린 시절 부부싸움이 잦음.\n부모님은 어린 시절 이혼해서 할머니 손에 자람.\n아버지는 알콜성 간질환으로 사망.", 1),
    Item("음주 및 약물 남용 과거력", "담배는 피우지 않음.\n방송국 입사 이후 최근 몇 년간 과도한 음주를 함.\n아나운서 2년차에 메인 뉴스의 아나운서를 맡고 나서 스트레스를 받은 것으로 추정.", 2),
    Item("사회적 과거", "이름: 대학 시절에는 주변에서 인기가 많았으며 과 대표를 맡은 경험도 있음.\n진행 능력을 살려 학교간 교류전에서 사회를 본 경험 있음.", 3),
    Item("사망 당시 대인관계", "메인 아나운서가 된 이후로는 사회적 교류가 줄어들고 주말에도 방에만 있었음.\n입사 초에는 간혹 방송국 동료들 얘기를 했으나 어느 순간부터 회사 언급을 피하게 됨.", 4),
    Item("이전 자살 시도력", "6개월 전 자살시도로 병원에 입원한 적이 있음.", 5),
    Item("사망 전 특징 및 행동 변화", "자살시도 전후로 기운이 없는 모습을 보임.\n자살 2-3일 전 집안 청소를 하는 모습 발견됨.", 7),
    Item("최근 스트레스", "직장에서의 따돌림으로 힘겨운 시간을 보내고 있었음.", 8)
    ]


screen inventory_screen():
    zorder 100
    modal True
    
    # 배경
    add "#000000aa"
    
    # 메인 프레임
    frame:
        xalign 0.5
        yalign 0.5
        xsize 800
        ysize 600
        padding (20, 20)
        
        vbox:
            spacing 10
            
            # 제목
            text "Report" size 30 xalign 0.5
            null height 10
            
            # 아이템 그리드
            viewport:
                xsize 760
                ysize 400
                scrollbars "horizontal"
                mousewheel True
                
                vbox:
                    hbox:
                        xsize 750
                        ysize 220

                        vbox:
                            yalign 0
                            text current_item.name size 36
                            text current_item.description size 30 color "#cccccc"
                    hbox:
                        spacing 5

                        for item_data in inventory.get_all_items():
                            $ item = item_data["item"]
                            $ quantity = item_data["quantity"]
                            
                            button:
                                xsize 80
                                ysize 80
                                # action SetScreenVariable("current_item", item)
                                action SetVariable("current_item", item)
                                # hovered SetVariable("current_item", item)
                                
                                hbox:
                                    spacing 15
                                    
                                    # 아이템 이미지 (없으면 기본 이미지)
                                    frame:
                                        text item.name
            # 제시 버튼
            hbox:
                spacing 10
                xalign 0.5

                textbutton "Close" action Function(toggle_inventory)

# 아이템 사용 함수
init python:
    def use_item(item_name):
        """아이템 사용 함수"""
        if item_name == "회복 포션":
            # HP 회복 로직 (예시)
            renpy.notify("HP가 50 회복되었습니다!")
            inventory.remove_item(item_name, 1)
        elif item_name == "열쇠":
            renpy.notify("열쇠를 사용했습니다!")
            inventory.remove_item(item_name, 1)
        else:
            renpy.notify("이 아이템은 사용할 수 없습니다.")

# 퀵 인벤토리 함수들
init python:
    def quick_add_item(item_name, quantity=1):
        """빠른 아이템 추가 함수"""
        items_dict = {
            "검": sword,
            "회복 포션": potion,
            "열쇠": key,
            "금화": coin
        }
        if item_name in items_dict:
            inventory.add_item(items_dict[item_name], quantity)
            renpy.notify(f"{item_name} {quantity}개를 획득했습니다!")

# 인벤토리 토글 함수
init python:
    def toggle_inventory():
        """인벤토리 화면을 토글하는 함수"""
        global inventory_open
        if inventory_toggleable:
            if inventory_open:
                renpy.hide_screen("inventory_screen")
                inventory_open = False
            else:
                renpy.show_screen("inventory_screen")
                inventory_open = True

# 단축키 설정 (선택사항)
init python:
    config.keymap['inventory_toggle'] = ['K_TAB']

# 인벤토리 단축키 바인딩
init:
    $ config.underlay.append(renpy.Keymap(inventory_toggle=Function(toggle_inventory)))