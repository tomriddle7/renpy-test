init python:
    # 아이템 클래스 정의
    class Item:
        def __init__(self, name="", description="", thumb=None, image=None, type="evid", uid=0):
            self.name = name
            self.description = description
            self.thumb = thumb
            self.image = image
            self.type = type
            self.uid = uid
    
    # 인벤토리 클래스
    class Inventory:
        def __init__(self):
            self.items = {}
            self.max_slots = 20
        
        def add_item(self, item, quantity=1):
            """아이템을 인벤토리에 추가"""
            if item.name in self.items:
                self.items[item.name]["quantity"] += quantity
            else:
                self.items[item.name] = {
                    "item": item,
                    "quantity": quantity
                }
            return True
        
        def remove_item(self, item_name, quantity=1):
            """아이템을 인벤토리에서 제거"""
            if item_name in self.items:
                self.items[item_name]["quantity"] -= quantity
                if self.items[item_name]["quantity"] <= 0:
                    del self.items[item_name]
                return True
            return False
        
        def has_item(self, item_name):
            """아이템 보유 여부 확인"""
            return item_name in self.items and self.items[item_name]["quantity"] > 0
        
        def get_quantity(self, item_name):
            """특정 아이템의 수량 반환"""
            if item_name in self.items:
                return self.items[item_name]["quantity"]
            return 0
        
        def get_items_by_type(self, item_type):
            """타입별 아이템 목록 반환"""
            return [data for data in self.items.values() 
                   if data["item"].type == item_type]

        def get_all_items(self):
            """모든 아이템 목록 반환"""
            return list(self.items.values())

# 전역 인벤토리 인스턴스
default inventory = Inventory()
default inventory_tab = "evid"
default current_item = Item()
default item_name = ""
default inventory_open = False
default inventory_toggleable = False

# 아이템 정의
init python:
    # 예시 아이템들
    badge = Item("Attornye's Badge", "No one would believe I was a defense attorney if I didn't carry this.", "images/icon/itc006.png", "images/icon/it006.png", "evid", 6)
    autopsy = Item("Cindy's Autopsy Report", "Time of death: 7/31, 4PM - 5PM Cause of death: loss of blood due to blunt trauma.", "images/icon/itc010.png", "images/icon/it010.png", "evid", 10)
    thinker = Item("Statue", "A statue in the shape of \"The Thinker.\" It's rather heavy.", "images/icon/itc00e.png", "images/icon/it00e.png", "evid", 11)
    passport = Item("Passport", "The victim apparently arrived home from Paris on 7/30, the day before the murder.", "images/icon/itc00fu.png", "images/icon/it00fu.png", "evid", 12)
    borecord = Item("Blackout Record", "Electricity to Ms. Stone's building was out from noon to 6PM on the day of the crime.", "images/icon/itc011.png", "images/icon/it011.png", "evid", 13)
    # 예시 프로필들
    chihiro = Item("Mia Fey(Age: 27)", "Chief Attorney at Fey & Co. My boss, and a very good defense attorney.", "images/icon/itc012.png", "images/icon/it012.png", "profile", 12)
    yahari = Item("Larry Butz(Age: 23)", "The defendant in this case. A likeable guy who has been my friend since grade school.", "images/icon/itc013.png", "images/icon/it013.png", "profile", 13)
    takabi = Item("Cindy Stone(Age: 23)", "The victim in this case. A model, she lived in an apartment by herself.", "images/icon/itc014.png", "images/icon/it014.png", "profile", 14)


screen inventory_screen():
    zorder 100
    modal True
    
    # 배경
    add "#000000aa"
    
    # 메인 프레임
    frame:
        xalign 0.5
        yalign 0.5
        xsize 800
        ysize 600
        padding (20, 20)
        
        vbox:
            spacing 10
            
            # 제목
            text "Inventory" size 30 xalign 0.5
            
            # 탭 버튼들
            hbox:
                spacing 10
                xalign 0.5
                
                textbutton "Evidence" action SetVariable("inventory_tab", "evid")
                textbutton "Profiles" action SetVariable("inventory_tab", "profile")
            
            null height 10
            
            # 아이템 그리드
            viewport:
                xsize 760
                ysize 400
                scrollbars "horizontal"
                mousewheel True
                
                vbox:
                    hbox:
                        xsize 750
                        ysize 220
                            
                        hbox:
                            spacing 15
                            
                            # 아이템 이미지 (없으면 기본 이미지)
                            if current_item.image:
                                add current_item.image size (208, 208)
                            else:
                                frame:
                                    xsize 208
                                    ysize 208
                                    background "#999999"
                            
                            vbox:
                                yalign 0
                                text current_item.name size 36
                                text current_item.description size 30 color "#cccccc"
                    hbox:
                        spacing 5
                        
                        # 현재 탭에 따른 아이템 표시
                        $ items_to_show = inventory.get_items_by_type(inventory_tab)
                        
                        for item_data in items_to_show:
                            $ item = item_data["item"]
                            $ quantity = item_data["quantity"]
                            
                            button:
                                xsize 80
                                ysize 80
                                # action SetScreenVariable("current_item", item)
                                action SetVariable("current_item", item)
                                # hovered SetVariable("current_item", item)
                                
                                hbox:
                                    spacing 15
                                    
                                    # 아이템 이미지 (없으면 기본 이미지)
                                    if item.thumb:
                                        add item.thumb size (60, 60)
                                    else:
                                        frame:
                                            xsize 60
                                            ysize 60
                                            background "#333333"
            # 제시 버튼
            hbox:
                spacing 10
                xalign 0.5
                
                if is_presenting:
                    textbutton "Present" action [Hide("inventory_screen"), Function(present_evid)]
                textbutton "Close" action Function(toggle_inventory)

# 아이템 사용 함수
init python:
    def use_item(item_name):
        """아이템 사용 함수"""
        if item_name == "회복 포션":
            # HP 회복 로직 (예시)
            renpy.notify("HP가 50 회복되었습니다!")
            inventory.remove_item(item_name, 1)
        elif item_name == "열쇠":
            renpy.notify("열쇠를 사용했습니다!")
            inventory.remove_item(item_name, 1)
        else:
            renpy.notify("이 아이템은 사용할 수 없습니다.")

# 퀵 인벤토리 함수들
init python:
    def quick_add_item(item_name, quantity=1):
        """빠른 아이템 추가 함수"""
        items_dict = {
            "검": sword,
            "회복 포션": potion,
            "열쇠": key,
            "금화": coin
        }
        if item_name in items_dict:
            inventory.add_item(items_dict[item_name], quantity)
            renpy.notify(f"{item_name} {quantity}개를 획득했습니다!")

# 인벤토리 토글 함수
init python:
    def toggle_inventory():
        """인벤토리 화면을 토글하는 함수"""
        global inventory_open
        if inventory_toggleable:
            if inventory_open:
                renpy.hide_screen("inventory_screen")
                inventory_open = False
            else:
                renpy.show_screen("inventory_screen")
                inventory_open = True

# 단축키 설정 (선택사항)
init python:
    config.keymap['inventory_toggle'] = ['K_TAB']

# 인벤토리 단축키 바인딩
init:
    $ config.underlay.append(renpy.Keymap(inventory_toggle=Function(toggle_inventory)))