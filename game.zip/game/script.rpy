﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

transform shake:
    ease 0.04 xoffset -30 yoffset 30
    ease 0.04 xoffset 30 yoffset -30
    ease 0.04 xoffset -30 yoffset -30
    ease 0.04 xoffset 30 yoffset 30
    repeat 1

define sis = Character("혜지")
define see = Character("상담사")
define fri = Character("병석")

label hold_effect:
    $ set_interrogation_var(False, False)
    see "잠시만요, 질문 하나만 드릴게요."
    $ renpy.call(jump_label_interrogate)
    $ set_interrogation_var(True, True)
    return

screen court_record():
    textbutton "Court Record" action Function(toggle_inventory) xalign 0.95 yalign 0.05
    
screen court_examine():
    textbutton "Present" action Function(toggle_inventory) xalign 0.95 yalign 0.05
    textbutton "Press" action Function(interrogate) xalign 0.05 yalign 0.05

# The game starts here.

label start:

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    scene black
    
    show walking:
        xpos -650
        ypos -100
        linear 1:
            xpos 50
    pause 1.5
    "또박또박..."

    show door:
        xpos 2570
        ypos 200
        linear 1:
            xpos 1050
    pause 1.5
    "(덜컹)"

    show kitchen:
        xpos -650
        ypos 500
        linear 1:
            xpos 50
    pause 1.5
    sis "영진아, 누나 왔어."
    sis "영진아, 자니?"
    "요즘 취업이 계속해서 어려워지자 동생은 더욱 힘들어하고 있다."
    "분명 대학 졸업할 때만 해도 장학금을 놓치지 않는 수재였던 동생이었다."
    "하지만 사회와 기업의 인사담당자들이 보는 동생은 그저 갓 대학을 졸업한, 경험없는 신출내기였을 뿐이다."
    "이래서야 동생이 기운 차릴 수 있으려나..."
    sis "영진아, 자고 있니?"
    
    scene black
    "(삐걱)"
    pause 1.0

    scene hangedman:
        xpos 560
        ypos -720
        linear 5:
            ypos -420
    with Dissolve(1.0)
    pause 5.0
    sis "영진아..."
    
    pause 3.0
    scene title
    with Dissolve(1.0)
    pause 3.0
label scene_1:
    scene counselroom
    show test
    with Dissolve(1.0)
    see "동생이 사망한지 2개월이 지나셨다고요."
    sis "네."
    see "심리상담을 요청하기까지 쉬운 결정이 아니었을텐데 어떤 계기로 상담을 요청하게 된 건가요?"
    sis "사건을 수사하던 경찰관님이 이곳을 권했어요."
    sis "부모님은 죽은 사람 얘기를 괜히 꺼낸다며 부담스러워 했지만, 이런 곳에라도 가지 않으면 더 힘들 것 같아서요."
    see "생전에 동생이 어떤 모습이었는지 설명 부탁드릴 수 있을까요?"
    sis "네."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    "Witness's Account"
label scene_2:
    $ set_testifying(2)
    $ set_interrogation_var(True, True)
    $ set_press("scene_1_1")
    $ set_evidence("scene_1_wrong")
    sis "동생은 1년 전부터 대학을 졸업하고 서울로 올라와서 저와 함께 살기 시작했어요."
    $ set_press("scene_1_2")
    sis "대학에서도 좋은 성적을 받아서 금방 취업할 수 있을 거라 생각했는데 구직기간이 길어지면서 힘들어하더라고요."
    $ set_press("scene_1_3")
    sis "점차 집에서 얼굴 보기도 힘들어지고 밖에 나오는 일도 줄어들었고요."
    $ set_press("scene_1_4")
    sis "부모님도 종종 전화해서 동생에 대해 걱정하곤 했어요."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    jump scene_2
label scene_1_1:
    see "동생과 함께 상경해서 사는 것은 동생이 내린 결정이었나요?"
    sis "아니요, 저는 임용고시를 합격해서 서울에 발령을 받아 먼저 서울에서 교사를 하고 있었어요. 그러던 중에 동생이 지방에서 대학을 졸업했고 기왕이면 같이 서울에서 사는 게 일자리 구하기 좋을 거라고 부모님이 얘기해서 같이 살게 됐어요."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    return
label scene_1_2:
    see "동생은 졸업하고 얼마나 됐나요?"
    sis "졸업하고 이제 3년 돼가는 참이었어요."
    see "혜지씨가 출근하고 나면 동생분은 뭐하는지 아시나요?"
    sis "아니요. 가끔 업무중에 문자를 하기도 하지만, 깊이있는 대화를 나눈 적은 없었고 보통은 제가 퇴근하고 저녁이 되면 그제서야 대화할 시간이 났어요."
    see "그러면 퇴근 후에는 동생과 어떤 얘기를 하셨나요?"
    sis "사실... 퇴근 후에도 동생과 많은 얘기를 하진 않았어요. 교사 일은 퇴근하고도 행적적인 업무라던가 생활기록부 작성하는 일만으로도 이미 지치고, 집에 돌아오면 동생은 제 저녁만 차려놓고 방에 들어앉아 있으니까 대화할 기회가 없었거든요."
    
    menu choice_1_1:
        see "(정말 동생은 혼자였을까? 대화나누는 상대조차 없었을까?)"
        "자세히 묻는다.":
            jump scene_3
        "그냥 넘어간다.":
            see "유가족이 아직 슬픔에 잠겨있을텐데, 이런 질문은 있다가 하자."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    return
label scene_1_3:
    see "두 분의 일상은 어떻게 되시나요?"
    sis "제가 먼저 아침을 간단히 먹고 출근을 해요."
    sis "보통 동생은 제가 출근하기 전까지만 방 안에만 있거든요."
    sis "그러면 제가 출근해서 일하는 동안 동생은 쌓여있는 설거지랑 구직 이력서 작성도 하고."
    sis "그리고 제가 퇴근할 시간이 되면 동생은 먼저 저녁을 먹고 제 저녁을 차려놓아요."
    sis "그러면 저는 제 저녁을 먹고 제 방에서 학교 업무를 처리하고요."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    return
label scene_1_4:
    see "부모님은 어떤 분이셨나요?"
    sis "좋은 분이세요."
    see "좋은 분... 그 말 말고는 할 게 없나요?"
    sis "네. 그냥 좋은 분. 남들과 특별히 다르지도 않은."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    return
label scene_1_wrong:
    see "혹시 더 하실 말씀이 있나요?"
    sis "네?"
    see "아뇨... 일단 계속하세요."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    return
label scene_3:
    $ set_testifying(0)
    see "동생분은 집 안에만 있었나요?"
    sis "가끔 밖에 친구 만나러 나간다고 할 때가 있는데, 무슨 친구인지는 모르겠어요."
    sis "제 생각엔 그리 좋은 친구는 아니었던 것 같아요. 제가 그 친구에 대해 자세히 물어볼 때마다 얘기를 피하기만 하고, 뭔가 숨기려는 게 있었거든요."
    see "혹시 그 친구분에 대해 아시는 게 있으신가요?"
    sis "네, 동생이 꺼림찍해하긴 했는데, 제가 어떻게든 연락처를 받아놓은 게 있었거든요."
    sis "여기로 연락하시면 될 거에요."
    see "네, 감사합니다. 추후에 상담이 더 필요하면 연락드리겠습니다."
    hide test
    with Dissolve(1.0)
    see "(사망자의 누나는 동생의 죽음에 아직 죄책감을 가지고 있지만, 그 기저에는 뭔가 숨기고 싶어하는 내용이 있다는 느낌을 받았다.)"
    see "(사망자의 인간관계에 대해 더 자세히 알려면 그 친구라는 사람과 인터뷰가 필요한 것 같다.)"
    scene black
    with Dissolve(1.0)
label scene_4:
    scene counselroom
    show test
    with Dissolve(1.0)
    see "생전에 영진 씨랑 가끔 만나고 하셨다고 하셨죠."
    fri "네."
    see "생전에 영진 씨가 어떤 모습이었는지 설명 부탁드릴 수 있을까요?"
    fri "네."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    "Witness's Account"
label scene_5:
    $ set_testifying(2)
    $ set_interrogation_var(True, True)
    $ set_press("scene_5_1")
    $ set_evidence("scene_1_wrong")
    fri "영진이는 저와 한 달에 한 두 번 만나는 사이였는데, 그 때마다 이런저런 얘기들을 나누었어요."
    $ set_press("scene_5_2")
    fri "평소에는 얼굴 보고 대화하는 사이는 아니다 보니까, 평소에는 SNS로 종종 대화했어요."
    $ set_press("scene_5_3")
    fri "같은 취미를 갖고 있다보니까, 그런 부분에 대해 자주 얘기하기도 했고요."
    $ set_press("scene_5_4")
    fri "나이도 비슷하고 하다보니, 가끔 취업 얘기를 하기도 했어요."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    jump scene_5
    return
label scene_5_1:
    see "병석 씨는 동생과 무슨 관계였나요?"
    fri "특별히 관계가 있는 건 아니었어요."
    see "부정기적으로 만나서 얘기하는 데 특별한 관계가 아니라고요?"
    fri "사실... 영진이랑 저는 온라인 커뮤니티에서 만난 사이였거든요. 영진이랑 저는 취미가 같아서 온라인 커뮤니티에서 종종 얘기했고, 그러다 마침 서로 근처에 사는 걸 알게 돼서 오프라인에서도 종종 만나는 사이가 됐어요."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    return
label scene_5_2:
    see "영진 씨랑 만나면 무슨 얘기를 하셨나오?"
    fri "보통 같이 보는 버튜버나 애니 얘기... 그리고 취업에 대한 얘기였어요. 저나 그친구나 대학 나오고 취업 못하는 건 마찬가지였으니까요."
    see "병석 씨는 지금 하는 일이 있으신가요?"
    fri "저도 정규직을 구하지 못한 건 마찬가지여서, 최근부터 패스트푸드점에서 아르바이트를 하고 있어요."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    return
label scene_5_3:
    see "최근 영진 씨에게 심경의 갑작스런 변화가 될 만한 일이 있었을까요?"
    fri "...그러고보니, 최근에 좋아하던 미나토 아쿠아라는 버튜버가 졸업을 했어요."
    see "졸업이요?"
    fri "버튜얼 유튜버 그룹에서 소속 멤버가 나가는 것을 의미해요."
    see "그 졸업이라는 표현이 잘 이해가 안가는데, 연기자가 소속 그룹에서 나갔다면, 아이돌처럼 개인으로 활동하면 되지 않나요?"
    fri "버튜버는 보통 기획사에서 캐릭터를 기획하고 디자인하기 때문에 회사에서 저작권을 가져요."
    fri "그렇기 때문에 졸업을 하면 회사나 멤버나 해당 캐릭터는 사용할 수 없게 돼버리거든요."
    fri "그렇게 되면 졸업한 멤버가 개인으로 활동하려면 이전까지의 경력은 무가 되고, 새 캐릭터를 만들어 방송할 수 밖에 없는 거에요."
    see "그래서, 그 미나토 아쿠아가 졸업한다는 소식을 들었을 때 병석씨는 어떤 반응을 보였나요?"
    fri "겉으로는 괜찮은 것처럼 보이려고 노력했지만, 속으로는 천불이 났을 거에요."
    fri "몇 년 동안 팬이기도 했고, 특히 솔로라이브를 한다고 했을 땐 좋아서 길길이 뛰었거든요."
    fri "알바비를 모아 직접 일본에 가서 공연을 보기도 했고."
    see "혹시 영진 씨가 그 문제로 가족과 상담한 적은 있었을까요?"
    fri "아뇨. 제가 알기론 영진이는 그런 얘기는 가족과 안하는 성격인데다, 그 일로 큰 상처를 입은 적이 있었어요."
    see "그게 어떤 일인가요?"
    fri "영진이가 그 일로 큰 상처를 입어서 가족에게 상담한 적 있었는데, 가족들은 현실도 아닌 인터넷 세상의 일이 그렇게 중요하냐며 회초리를 들었다고 하더라고요."
    fri "정작 본인은 그 일로 실신해서 병원에 실려간 일까지 있었는데."
    scene black
    with Dissolve(1.0)
    scene counselroom
    show test
    with Dissolve(1.0)
    return
label scene_5_4:
    see "영진 씨가 취업 얘기를 하면 무슨 얘기를 했나요?"
    fri "취업하려고 노력하는데 쉽지 않다는 얘기도 했고... 그리고 가족들의 압박 때문에 지쳐간다는 얘기도 했어요."
    fri "본인 입에서 나오는 말만 들으면 취준생 기간이 길어지는 동생을 걱정하는 얘기 같았지만... 본인은 그걸 부담으로 받아들이는 듯 했어요."
    fri "본인은 건축학과를 나와서 가족들은 공무원 시험을 봐서 평범하게 기술직 공무원이 되었으면 했지만, 본인은 평소에 본인이 관심있던 게임, 만화나 애니메이션 쪽으로 가고 싶어했어요."
    jump scene_6
    return
label scene_6:
    $ set_testifying(0)
    see "네, 감사합니다. 추후에 상담이 더 필요하면 연락드리겠습니다."
    hide test
    with Dissolve(1.0)
    see "(친구의 이야기에 따르면, 사망자는 생각만큼 가족과 사이가 좋지 않았고, 특히 본인이 가고자 하는 길과 가족의 기대가 어긋남에 고통받고 있던 것 같다.)"
    see "(사망자에 대해 좀 더 자세한 이야기가 필요한 것 같다.)"
    $ renpy.set_return_stack([])
    scene black
    with Dissolve(1.0)
    return