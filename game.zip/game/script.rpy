﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define sis = Character("혜지")
define see = Character("상담사")


# The game starts here.

label start:

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    scene black
    
    show walking:
        xpos -650
        ypos -100
        linear 1:
            xpos 50
    pause 1.5
    "또박또박..."

    show door:
        xpos 2570
        ypos 200
        linear 1:
            xpos 1050
    pause 1.5
    "(덜컹)"

    show kitchen:
        xpos -650
        ypos 500
        linear 1:
            xpos 50
    pause 1.5
    sis "영진아, 누나 왔어."
    sis "영진아, 자니?"
    "요즘 취업이 계속해서 어려워지자 동생은 더욱 힘들어하고 있다."
    "분명 대학 졸업할 때만 해도 장학금을 놓치지 않는 수재였던 동생이었다."
    "하지만 사회와 기업의 인사담당자들이 보는 동생은 그저 갓 대학을 졸업한, 경험없는 신출내기였을 뿐이다."
    "이래서야 동생이 기운 차릴 수 있으려나..."
    sis "영진아, 자고 있니?"
    
    scene black
    "(삐걱)"
    pause 1.0

    scene hangedman:
        xpos 560
        ypos -720
        linear 5:
            ypos -420
    with Dissolve(1.0)
    pause 5.0
    sis "영진아..."
    
    pause 3.0
    scene title
    with Dissolve(1.0)
    pause 3.0
label scene_1:
    scene counselroom
    with Dissolve(1.0)
    see "동생이 사망한지 2개월이 지나셨다고요."
    sis "네."

    return
