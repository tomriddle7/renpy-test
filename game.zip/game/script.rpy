﻿# The script of the game goes in this file.

transform midleft:
    xcenter 0.25

image office = "images/room.png"
image office_parts = "images/desk.png"
image wife = At("images/jeremy.png", midleft)

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define n = Character(None, kind=nvl)
define q = Character("???")
define hero = Character("의사", color="#091057")
define mrs_br = Character("제레미 브랜트", color="#EC8305")
define herbert = Character("주치의", color="#024CAA")
define co = Character("직장동료", color="#DBD3D3")

default characterset = set()
default current_position = ""
default current_character = ""

default come_office = False
default come_cafe = False
default meet_mrs_br = False
default meet_herbert = False
default meet_co = False

default com_topic = ""

default menu_stack = ["action_screen"]
init python:
    def menu_push(item):
        renpy.hide_screen(menu_stack[-1])
        menu_stack.append(item)
        renpy.show_screen(menu_stack[-1])

    def menu_pop():
        renpy.hide_screen(menu_stack[-1])
        menu_stack.pop()
        renpy.show_screen(menu_stack[-1])

    class use_itme:
        def __init__ (self, img, value, use):
            self.img = img
            self.value = value
            self.use = False
        def use(self):
            self.use = True

    # -----------------------------------------------------------
    # 1. 카드 데이터 클래스 정의
    # -----------------------------------------------------------
    class Evidence:
        def __init__(self, name, x, y, text_content=None):
            self.name = name        # ID 겸 정답 확인용 이름
            self.x = x              # 원래 위치 X
            self.y = y              # 원래 위치 Y
            self.text = text_content if text_content else name # 화면에 표시될 텍스트

    # 빈칸(슬롯) 클래스 [NEW]
    class Slot:
        def __init__(self, name, text_content, x, y):
            self.name = name        # 슬롯 ID (정답지의 키와 일치해야 함)
            self.text = text_content
            self.x = x
            self.y = y
    # -----------------------------------------------------------
    # 2. 게임 상태 변수들
    # -----------------------------------------------------------
    current_cards = []      # 현재 화면에 보여줄 카드들
    current_slots = []      # 현재 화면에 보여줄 빈칸들 [NEW]
    correct_answers = {}    # 현재 적용될 정답 규칙 { "슬롯ID": "카드ID" }
    placed_cards = {}       # 플레이어가 놓은 상태

    # -----------------------------------------------------------
    # 3. 도우미 함수들
    # -----------------------------------------------------------
    
    # 이름으로 카드 객체를 찾는 함수 (원래 위치로 돌려보낼 때 필요)
    def get_card_by_name(name):
        for card in current_cards:
            if card.name == name:
                return card
        return None

    # 카드를 드래그 했을 때 실행되는 함수
    def card_dragged(drags, drop):
        card_obj = drags[0]
        
        # 기존에 꽂혀있던 슬롯에서 정보 제거
        for slot_name in list(placed_cards.keys()):
            if placed_cards[slot_name] == card_obj.drag_name:
                del placed_cards[slot_name]

        if drop:
            # 빈칸에 놓았을 때 -> 자석 붙이기 & 기록
            card_obj.snap(drop.x, drop.y)
            placed_cards[drop.drag_name] = card_obj.drag_name
        else:
            # 허공에 놓았을 때 -> 원래 자리(Home) 찾아서 복귀
            original_data = get_card_by_name(card_obj.drag_name)
            if original_data:
                card_obj.snap(original_data.x, original_data.y, delay=0.2)
        
        return

    # 제출 버튼 체크 함수
    def check_submission():
        if len(placed_cards) < len(correct_answers):
            renpy.notify("빈칸을 모두 채워주세요.")
            return

        is_correct = True
        # correct_answers에 있는 내용만 검사합니다.
        for slot, answer in correct_answers.items():
            print(placed_cards.get(slot))
            print(answer)
            if placed_cards.get(slot) != answer:
                is_correct = False
                break
        
        if is_correct:
            renpy.hide_screen("investigation_board")
            renpy.jump("ending")
        else:
            renpy.notify("틀렸습니다. 다시 추리해보세요.")
            return

style btns_button:
    xysize (200, 80)
    background "gui/button/check_selected_foreground.png"
    hover_background "gui/button/check_selected_foreground.png"
    
label nav_screen_label:
    window hide
    call screen counsel0
    return

label reaction0:
    if scene_hash == "000000":
        hero "우선, 성함과 고인과의 관계에 대해 부탁드리겠습니다."
        mrs_br "제 이름은 도로시 브라운고, 68살이에요. 고인의 부인이었지요."
        $ scene_hash = "000001"
        window hide
        call screen counsel1
    return

screen character_screen():
    vbox:
        textbutton "뒤로가기" action Function(menu_pop)
    hbox:
        xalign 0.5 yalign 0.5
        if current_position == "office":
            textbutton "부인" action [Function(renpy.hide_screen, "character_screen"), Jump("mrs_brown")]
        if current_position == "cafe":
            textbutton "주치의" action [Function(renpy.hide_screen, "character_screen"), Jump("herbert")]
        if current_position == "office":
            textbutton "직장동료" action [Function(renpy.hide_screen, "character_screen"), Jump("coworker")]

screen position_screen():
    vbox:
        textbutton "뒤로가기" action Function(menu_pop)
    hbox:
        xalign 0.5 yalign 0.5
        if current_position != "office":
            textbutton "사무실" action [Function(renpy.hide_screen, "position_screen"), Function(menu_stack.pop), Jump("office")]
        if current_position != "cafe":
            textbutton "카페" action [Function(renpy.hide_screen, "position_screen"), Function(menu_stack.pop), Jump("cafe")]

# https://raon0229.tistory.com/97
screen item_screen():
    vbox:
        textbutton "뒤로가기" action Function(menu_pop)
    vbox:
        xalign 0.5 yalign 0.5
        spacing 20
        for i in view_items:
            textbutton "[i]"

screen comm_screen():
    hbox:
        textbutton "대화하기" action [SetVariable("com_topic", ""), Show("enterName")]
        textbutton "사건일지" action Show("investigation_board")
        textbutton "보고서" action Function(toggle_inventory)

label test_topic:
    $ com_topic = renpy.input("What topic?")
    jump continue

screen enterName:
    frame:
        xalign 0.5
        yalign 0.5
        padding (20, 20)

        vbox: #now we want to do vbox to make the input bellow the textbox
            xalign 0.5 #with this you define location of the vbox (if you would type xalign 0 and yalign 0 it would appear in top left corner)
            yalign 0.5 #there is a link to all of positional properties: https://www.renpy.org/doc/html/style_properties.html#position-style-properties
            text "어떤 주제로 이야기하시겠습니까?": #we added text using this
                size 20 #in here you can edit the text with those: https://www.renpy.org/doc/html/style_properties.html#text-style-properties

            input default "":#now we add input which will be below the text because it's in the vbox. In default you can type something that will be already typed when the screen will be shown
                pixel_width(500)#this to not allow too long name
                value VariableInputValue("com_topic")#with this you save the input to a variable.

            hbox:
                spacing 10
                xalign 0.5
                textbutton "OK":
                    action Call("continue")#in action you type what will happen, when you click ok
                    keysym('K_RETURN', 'K_KP_ENTER') #you can also add keysym to activate it with a keyboard
                    # activate_sound("audio/tick.ogg") #you can also add a sound when clicked

screen investigation_board():
    
    add Solid("#f0e6d2") 
    text "사 건 일 지" xalign 0.25 yalign 0.1 color "#000" size 40 bold True
    textbutton "창 닫기" xalign 0.8 yalign 0.1  action [Hide("investigation_board")]

    draggroup:
        # [NEW] 리스트에 있는 만큼 '빈칸(Slot)' 자동 생성
        for slot_data in current_slots:
            drag:
                drag_name slot_data.name
                child Frame(Text(slot_data.text, color="#aaa"), xysize=(200, 60), background=Solid("#e0e0e0"))
                draggable False
                droppable True
                xpos slot_data.x 
                ypos slot_data.y

        # 리스트에 있는 만큼 '카드(Card)' 자동 생성
        for card_data in current_cards:
            drag:
                drag_name card_data.name
                child Frame(Text(card_data.text, color="#000", xalign=0.5, yalign=0.5), xysize=(200, 60), background=Solid("#ffcc80"))
                droppable False
                dragged card_dragged
                xpos card_data.x 
                ypos card_data.y

    # 제출 버튼
    textbutton "제출":
        align (0.5, 0.9)
        text_size 30
        text_color "#fff"
        background Solid("#d32f2f")
        padding (20, 10)
        action Function(check_submission)

# The game starts here.

label start:

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    # --- [초기화] ---
    $ current_cards = []
    $ current_slots = []
    $ correct_answers = {}
    $ placed_cards = {}

label office:
    $ current_position = "office"
    scene office
    show office_parts at center
    if come_office is True:
        pass
    else:
        with Dissolve(1.0)
        nvl clear
        window show

        n "MBC 기상캐스터 오요안나가 9월 15일 사망했다. 향년 28세."
        n "아이돌 연습생 출신이던 고인은 2017년 JYP 13기 공채 오디션에 합격했으며, 2019년 춘향선발대회에서 숙으로 당선됐다."
        n "2021년 MBC 공채 기상캐스터로 입사해 평일·주말 뉴스 날씨를 맡았다."
        n "2022년 tvN '유 퀴즈 온 더 블럭'에 출연해 화제를 모았으나 지난해 9월 갑작스레 세상을 떠났다."
        n "이후 지난 달 27일 고인의 휴대전화에서 원고지 17장(약 2750자)의 분량의 유서가 발견돼 고인에 대한 직장 내 괴롭힘 의혹이 제기됐다."
        n "앞서 유족은 지난 달 23일 중앙지방법원에 고인의 동료 직원을 상대로 이에 따른 손해배상 청구 소송을 냈다."
        n "(후략)"

        nvl clear
        window hide

        $ characterset.clear()
        $ come_office = True
    window hide
    
    $ current_slots.append(Slot("name_slot", "사망자 이름", 250, 250))
    $ correct_answers["name_slot"] = "앤더슨 브랜트"
    $ current_slots.append(Slot("job_slot", "직업", 250, 400))
    $ correct_answers["job_slot"] = "아나운서"
    $ current_slots.append(Slot("reason_slot", "사망 계기", 250, 550))
    $ correct_answers["reason_slot"] = "따돌림"
    
    $ current_cards.append(Evidence("아나운서", 800, 150))
    $ current_cards.append(Evidence("연극배우", 1050, 150))
label character_choice:
    $ inventory.add_item(interview[0])
    $ inventory_toggleable = True
    jump mrs_brown
label ending:
    "모든 사건의 전말이 밝혀졌습니다. 게임 클리어!"
    $ MainMenu(confirm=False)()