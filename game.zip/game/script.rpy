﻿# The script of the game goes in this file.

init:
    define flash = Fade(.25, 0.0, .75, color="#fff")

transform shake:
    ease 0.04 xoffset -30 yoffset 30
    ease 0.04 xoffset 30 yoffset -30
    ease 0.04 xoffset -30 yoffset -30
    ease 0.04 xoffset 30 yoffset 30
    repeat 1

image areabutton = "images/area_temp.png"

image bg000 = im.FactorScale("images/bg/bg000.png", 0.67)
image bg000t = im.FactorScale("images/bg/bg000t.png", 0.67)
image bg00a = im.FactorScale("images/bg/bg00a.png", 0.67)
image bg01b = im.FactorScale("images/bg/bg01b.png", 0.67)
image bg01c = im.FactorScale("images/bg/bg01c.png", 0.67)
image bg02a = im.FactorScale("images/bg/bg02a.png", 0.67)
image bg02b = im.FactorScale("images/bg/bg02b.png", 0.67)
image bg009 = im.FactorScale("images/bg/bg009.png", 0.67)
image bg011 = im.FactorScale("images/bg/bg011.png", 0.67)
image bg014 = im.FactorScale("images/bg/bg014.png", 0.67)
image bg015a = im.FactorScale("images/bg/bg015a.png", 0.67)
image bg021 = im.FactorScale("images/bg/bg021.png", 0.67)
image bg021a = im.FactorScale("images/bg/bg021a.png", 0.67)
image bg021b = im.FactorScale("images/bg/bg021b.png", 0.67)
image bg022 = im.FactorScale("images/bg/bg022.png", 0.67)
image bg023 = im.FactorScale("images/bg/bg023.png", 0.67)
image bg023a = im.FactorScale("images/bg/bg023a.png", 0.67)
image bg024 = im.FactorScale("images/bg/bg024.png", 0.67)
image bg025 = im.FactorScale("images/bg/bg025.png", 0.67)
image bg026 = im.FactorScale("images/bg/bg026.png", 0.67)

image bg_court_lobby = im.FactorScale("images/bg/bg002.png", 0.67)
image bg_court = im.FactorScale("images/bg/bg006.png", 0.67)
image bg_judge = im.FactorScale("images/bg/bg008.png", 0.67)
image bg_lawyer = im.FactorScale("images/bg/bg003.png", 0.67)
image bg_lawyer_table = im.FactorScale("images/bg/etc22.png", 0.67)
image bg_prosecutor = im.FactorScale("images/bg/bg004.png", 0.67)
image bg_prosecutor_table = im.FactorScale("images/bg/etc21.png", 0.67)
image bg_lawyer_support = im.FactorScale("images/bg/bg007.png", 0.67)
image bg_witness = im.FactorScale("images/bg/bg005.png", 0.67)
image bg_witness_table = im.FactorScale("images/bg/etc20.png", 0.67)

image gavel_board = im.FactorScale("images/bg/gavel_board.png", 0.67)
image gavel_hammer = im.FactorScale("images/bg/gavel_hammer.png", 0.67)
image objection = im.FactorScale("images/etc00au.png", 0.55)
image hold_it = im.FactorScale("images/etc00bu.png", 0.55)
image take_that = im.FactorScale("images/etc012u.png", 0.55)

define q = Character("???")
define na = Character("Phoenix", image="naruhodo")
define chi = Character("Mia", image="chihiro")
define yah = Character("Butz", image="yahari")
define jdg = Character("Judge", image="judge")
define ouch = Character("Payne", image="ouch")
define yamn = Character("Sahwit", image="yamano")
define mayo = Character("Maya", image="mayoi")

image naruhodo normal = im.FactorScale("images/naruhodo0.png", 0.67)
image naruhodo thinking = im.FactorScale("images/naruhodo1.png", 0.67)
image naruhodo nervous = im.FactorScale("images/naruhodo2.png", 0.67)
image naruhodo surprising = im.FactorScale("images/naruhodo3.png", 0.67)
image naruhodo smashing = im.FactorScale("images/naruhodo4.png", 0.67)
image naruhodo confident = im.FactorScale("images/naruhodo5.png", 0.67)
image naruhodo checking = im.FactorScale("images/naruhodo6.png", 0.67)
image naruhodo protesting = im.FactorScale("images/naruhodo7.png", 0.67)
image chihiro standing = im.FactorScale("images/chihiro0.png", 0.67)
image chihiro surprising = im.FactorScale("images/chihiro1.png", 0.67)
image chihiro court_normal = im.FactorScale("images/chihiro2.png", 0.67)
image chihiro court_angry = im.FactorScale("images/chihiro3.png", 0.67)
image yahari crying = im.FactorScale("images/yahari0.png", 0.67)
image yahari nervous = im.FactorScale("images/yahari1.png", 0.67)
image yahari court_normal = im.FactorScale("images/yahari5.png", 0.67)
image yahari court_angry = im.FactorScale("images/yahari2.png", 0.67)
image yahari court_nervous = im.FactorScale("images/yahari4.png", 0.67)
image judge normal = im.FactorScale("images/judge1.png", 0.67)
image ouch normal = im.FactorScale("images/ouch0.png", 0.67)
image ouch nervous = im.FactorScale("images/ouch1.png", 0.67)
image yamano normal = im.FactorScale("images/yamano0.png", 0.67)
image mayoi depressed = im.FactorScale("images/mayoi1.png", 0.67)

# Declare characters used by this game. The color argument colorizes the
# name of the character.

default characterset = set()
default current_position = ""
default current_character = ""
default current_examine_screen = ""

default current_pos = 0

# The game starts here.

screen action_screen():
    hbox:
        xalign 0.5 yalign 0.5
        textbutton "Examine" action [Hide("action_screen"), Show(current_examine_screen)]
        textbutton "Move" action [Hide("action_screen"), Show("move_location_label")]
        
screen court_record():
    textbutton "Court Record" action Function(toggle_inventory) xalign 0.95 yalign 0.05
    
screen court_examine():
    textbutton "Present" action Function(toggle_inventory) xalign 0.95 yalign 0.05
    textbutton "Press" action Function(interrogate) xalign 0.05 yalign 0.05

label hold_effect:
    $ set_interrogation_var(False, False)
    show hold_it at center, shake
    $ renpy.pause(1.0)
    hide hold_it
    $ renpy.call(jump_label_interrogate)
    $ set_interrogation_var(True, True)
    return

label present_evid_effect:
    # if is_interrogating:
    #     show objection at center
    #     $ renpy.pause(1.0)
    #     hide objection
    # else:
    #     show objection at center
    #     $ renpy.pause(1.0)
    #     hide objection
    $ set_interrogation_var(False, False)
    show objection at center, shake
    $ renpy.pause(1.0)
    hide objection
    $ inventory_open = False
    if present_item_uid > 0 and current_item.uid == present_item_uid:
        $ renpy.pop_call()
        $ renpy.pop_call()
        $ renpy.jump(jump_label_present)
    else:
        $ renpy.call(jump_label_present)
        $ set_interrogation_var(True, True)
    return

label bg_gavel:
# screen으로 수정
    transform gavel_slam(y_val):
        ypos y_val
        pause 0.3
        ypos 0

    scene bg01b
    show gavel_board
    show gavel_hammer at gavel_slam(-635)
    show bg01c
    pause 1.3
    return
    
label bg_judge(args):
    scene bg_judge
    show expression args as img_judge
    return
label bg_prosecutor(args):
    scene bg_prosecutor
    show expression args as img_prosecutor
    show bg_prosecutor_table
    return
label bg_lawyer(args):
    scene bg_lawyer
    show expression args as img_lawyer
    show bg_lawyer_table
    return
label bg_lawyer_support(args):
    scene bg_lawyer_support
    show expression args as img_lawyer_support
    return
label bg_witness(args):
    scene bg_witness
    show expression args as img_witness
    show bg_witness_table
    return
    
label start:
    jump game_select