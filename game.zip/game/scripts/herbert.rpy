﻿label herbert:
    $ current_character = "doct"
    show doct
    if meet_herbert is True:
        jump choice_herbert_1
    else:
        with Dissolve(1.0)
    window hide
label scene_herbert_1:
    $ meet_herbert = True
    hero "안녕하십니까, 허버트씨. 지난 학회 이후로 오래간만입니다."
    herbert "그렇습니다. 그 때 조만간 다시 보자고 했었는데, 이런 형태로 만나게 될 줄은 몰랐네요."
label choice_herbert_1:
show screen back_screen
menu:
    "고인의 질병":
        $ characterset.add("choice_herbert_1_1")
        hide screen back_screen
        hero "고인이 사망전에 특별히 앓던 질환이 있었나요?"
        herbert "예. 몇 년 전부터 시력이 나빠져서 한쪽 눈이 전혀 보이지 않았습니다. 그 뒤로는 다른 한쪽 눈만으로도 일상생활에 문제는 없었지만 최근에는 다른 쪽 눈 시력도 떨어지기 시작했죠."
        hero "다른 쪽 눈의 시력이 떨어지기 시작한 게 언제부터였나요?"
        herbert "대략 두 달 전부터 증상이 나타나기 시작했습니다."
    "질병의 최근 변화" if "choice_herbert_1_1" in characterset:
        $ characterset.add("choice_herbert_1_2")
        hide screen back_screen
        hero "다른 쪽 눈의 시력이 떨어진다는 것을 알았을 때 고인은 어떤 반응을 보였나요?"
        herbert "지난 몇 년간 눈건강에 집중했음에도 시력이 떨어진다는 것을 알고 충격을 받은듯 했습니다. 그래서 환자에게 나이가 듦에 따라 시력이 떨어지는 것은 자연스러운 일이고, 약물과 수술을 통해 충분히 시력을 유지할 수 있다고 위로했죠."
        hero "그 이야기가 고인에게 얼마나 위안이 되었을까요?"
        herbert "그 자리에서는 제 설명을 듣고 납득한 것처럼 보였지만, 내심 우울을 완전히 떨쳐버리지는 못한 모습이었습니다."
jump choice_herbert_1