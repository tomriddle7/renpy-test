﻿label coworker:
    $ current_character = "coworker"
    show coworker behind desk_parts
    if meet_co is True:
        jump choice_coworker_1
    else:
        with Dissolve(1.0)
    window hide
label scene_coworker_1:
    $ meet_co = True
    hero "안녕하세요, 워커 씨. 장례식 이후로 시간이 꽤 흘렀는데, 감정은 좀 진정되셨나요?"
    co "네. 로버트의 죽음은 슬픈 일이지만, 시간이 흘러서 그 때보다는 한결 나아진 기분입니다."
label choice_coworker_1:
show screen back_screen
menu:
    "고인의 평판":
        $ characterset.add("choice_coworker_1_1")
        hide screen back_screen
        hero "고인은 직장에서 어떤 분이셨습니까?"
        co "그는 직장에서 굉장히 신뢰받고 존경받는 사람이었어요. 정년을 넘겨 은퇴할 시기가 되었는데도 후임자를 교육해달라는 회사의 부탁을 받고 계속 근무중이었으니까요."
        co "또 그 사람과 같은 동네에 살며 동호회 활동도 했었는데, 사람이 밝고 사교적이어서 회장으로 있으면서 많은 기여를 했었습니다."
    "고인의 당일 행적":
        $ characterset.add("choice_coworker_1_2")
        hide screen back_screen
        hero "사망 당일 고인의 행적에 대해 좀 더 자세히 알려주시죠."
        co "오전에는 동호회 지인들끼리 골프를 쳤습니다. 오래 전부터 계획했던 일이었거든요. 거기서 1등을 해서 좋아했지요. 그리고 오후에는 동호회 정기 모임을 주최하기 위한 준비를 했습니다."
        hero "당일 고인이 평소와 다른 모습을 보이거나 한 부분은 있었나요?"
        co "아니요. 특별히 다른 모습을 보이진 않았습니다. 동호회 일 말고도 직장에서도 자주 보던 사이라 달라진 점이 있었을 텐데 당사자에게서 그런 모습은 보지 못했습니다."
    "고인의 고민":
        $ characterset.add("choice_coworker_1_3")
        hide screen back_screen
        hero "고인이 은퇴할 시기가 됐다고 했는데 그로 인한 스트레스 같은 건 없었습니까?"
        co "몇 달 전부터 은퇴 시기가 다가오자 몇십년간 일한 직장을 떠나 은퇴생활을 한다는 것에 대해 두려워하는 느낌이었습니다."
        hero "그래서 어떻게 대처하셨나요?"
        co "그래서 은퇴하고 즐길 수 있는 편안한 여가생활을 상상해보라는 이야기도 했고, 이전 은퇴자들을 연결시켜주며 은퇴생활을 잘 누리고 있는 모습을 보여주기도 했습니다."
        hero "고인이 그러한 조언을 듣고 위안이 되었나요?"
        co "겉으로는 내색하지 않았지만... 내심 불안이 가시지는 않은 듯 했습니다. 하지만 워낙 자존심이 강한 사람이라 그것을 밖에 드러내지는 않으려고 했어요."
jump choice_coworker_1