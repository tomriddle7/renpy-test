label game_select:
    menu gs_1_episode:
        "Which episode do you start?"
        
        "The First Turnabout":
            call gs1_1_1
        
        "Turnabout Sisters":
            call gs1_2_1
        
        "Turnabout Samurai":
            "This episode is not support yet."
            jump gs_1_episode
        
        "Turnabout Goodbyes":
            "This episode is not support yet."
            jump gs_1_episode
        
        "Exit game":
            "Exit game."
            return