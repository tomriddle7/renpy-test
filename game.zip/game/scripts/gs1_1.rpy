﻿label gs1_1_1:
    window hide None
    scene bg021b
    "*gasp*... *gasp*..."
    scene bg021:
        ypos -720
        linear 10:
            ypos 0
    $ renpy.pause()
    scene bg021a
    $ renpy.pause()
    
    scene bg022
    with Dissolve(1.0)
    "Dammit! ...Why me?"
    "I can't get caught... Not like this!"
     
    scene bg023:
        ypos (-720)
        linear 10:
            ypos 0
    $ renpy.pause()
    scene bg023a
    "I-I've gotta find someone to pin this on..."
    
    scene bg024
    with flash
    $ renpy.pause (0.5)
    scene bg025
    with flash
    $ renpy.pause (0.5)
    scene bg026
    with flash
    $ renpy.pause (0.5)
    "Someone like... him!"
    scene bg02a
    $ renpy.pause (0.5)
    scene bg026
    with flash
    $ renpy.pause (0.5)
    "I'll make it look like HE did it!"
#**************************************
label gs1_1_2:
    scene black
    with None
    "August 3, 9:47 AM\nDistrict Court\nDefendant Lobby No. 2"

    $ current_position = "court_lobby"
    $ set_testifying(0)
    $ inventory.add_item(badge)
    $ inventory.add_item(autopsy)
    $ inventory.add_item(chihiro)
    $ inventory.add_item(yahari)
    $ inventory.add_item(takabi)
    $ inventory_toggleable = True
    scene bg_court_lobby
    na "(Boy am I nervous!)"
    chi "Wright!"
    show chihiro standing at center
    with Dissolve(1.0)
    na "Oh, h-hiya, Chief."
    chi "Whew, I'm glad I made it on time."
    chi "Well, I have to say Phoenix, I'm impressed!"
    chi "Not everyone takes on a murder trial right off the bat like this."
    chi "It says a lot about you... and your client as well."
    na "Um... thanks."
    na "Actually, it's because I owe him a favor."
    show chihiro surprising
    chi "A favor?"
    chi "You mean, you knew the defendant before this case?"
    na "Yes."
    na "Actually, I kind of owe my current job to him."
    na "He's one of the reasons I became an attorney."
    show chihiro standing
    chi "Well, that's news to me!"

    na "I want to help him out any way I can!"
    na "I just... really want to help him. I owe him that much."
    show chihiro surprising
    q "(It's over!)"
    q "(My life, everything, it's all over!)"

    chi "..."
    chi "Is that your client screaming over there?"
    show chihiro standing
    na "Yeah... it's him."

    q "(Death! Despair! Ohhhh!)"
    show chihiro surprising
    q "(I'm gonna do it, I'm gonna die!!!)"

    chi "It sounds like he wants to die..."
    show chihiro standing
    na "Um, yeah. *sigh*"
    hide chihiro
    with Dissolve(1.0)
    show yahari crying at center
    with Dissolve(1.0)
    
    yah "Nick!!!"
    na "Hey.\nHey there, Larry."
    show yahari nervous
    yah "Dude, I'm so guilty!!\nTell them I'm guilty!!!"
    yah "Gimme the death sentence! I ain't afraid to die!"
    na "What!?\nWhat's wrong, Larry?"
    show yahari crying
    yah "Oh, it's all over...\nI... I'm finished. Finished!"
    yah "I can't live in a world without her! I can't!"
    yah "Who... who took her away from me, Nick? Who did this!?"
    yah "Aww, Nick, ya gotta tell me! Who took my baby away!?"
    na "(Hmm... The person responsible for your girlfriend's death?)"
    na "(The newspapers say it was you...)"
    scene black
    with Dissolve(1.0)
    na "My name is Phoenix Wright."
    na "Here's the story:"
    na "My first case is a fairly simple one."
    scene bg022
    with Dissolve(1.0)
    na "A young woman was killed in her apartment."
    na "The guy they arrested was the unlucky sap dating her:"
    scene black
    with Dissolve(1.0)
    show yahari nervous
    na "Larry Butz... my best friend since grade school."
    na "Our school had a saying:\n\"When something smells, it's usually the Butz.\""
    show yahari crying
    na "In the 23 years I've known him, it's usually been true."
    na "He has a knack for getting himself in trouble."
    na "One thing I can say though:\nit's usually not his fault. He just has terrible luck."
    hide yahari
    with Dissolve(1.0)
    na "But I know better than anyone, that he's a good guy at heart."
    na "That and I owe him one. Which is why I took the case... to clear his name."
    na "And that's just what I'm going to do!"
#**************************************
label gs1_1_3:
    scene black
    with None
    "August 3, 10:00 AM\nDistrict Court\nCourtroom No. 2"
    $ current_position = "court"
    scene bg_court
    $ renpy.pause(1.0)
    call bg_gavel
    call bg_judge("judge normal")
    jdg "Court is now in session for the trial of Mr. Larry Butz."
    call bg_prosecutor("ouch normal")
    ouch "The prosecution is ready, Your Honor."
    call bg_lawyer("naruhodo normal")
    na "The, um, defense is ready, Your Honor."
    call bg_judge("judge normal")
    jdg "Ahem."
    jdg "Mr. Wright?"
    jdg "This is your first trial, is it not?"
    call bg_lawyer("naruhodo normal")
    na "Y-Yes, Your Honor.\nI'm, um, a little nervous."
    call bg_judge("judge normal")
    jdg "Your conduct during this trial will decide the fate of your client."
    jdg "Murder is a serious charge. For your client's sake, I hope you can control your nerves."
    call bg_lawyer("naruhodo normal")
    na "Thank... thank you, Your Honor."
    call bg_judge("judge normal")
    jdg "..."
    jdg "Mr. Wright, given the circumstances..."
    jdg "I think we should have a test to ascertain your readiness."
    call bg_lawyer("naruhodo normal")
    na "Yes, Your Honor."
    show naruhodo nervous as img_lawyer
    na "(Gulp... Hands shaking... Eyesight... fading...)"
    call bg_judge("judge normal")
    jdg "The test will consist of a few simple questions. Answer them clearly and concisely."
    menu choice_1_1_1:
        jdg "Please state the name of the defendant in this case."
        "Phoenix Wright":
            call bg_lawyer("naruhodo normal")
            na "Um... the defendant... is me... right?"
            call bg_lawyer_support("chihiro court_angry")
            chi "Wright! Have you completely lost your mind? Focus! The defendant is the person on trial! You're his lawyer!"
            na "Um, er, eh? Oh yeah, right! Eh heh heh."
            chi "This is no laughing matter! You did pass the bar, didn't you?"
            call bg_judge("judge normal")
            jdg "Sorry, I couldn't hear your answer. I'll ask once more:"
            jump choice_1_1_1
        "Larry Butz":
            call bg_lawyer("naruhodo thinking")
            na "The defendant? Well, that's Larry Butz, Your Honor."
        "Mia Fey":
            call bg_lawyer("naruhodo normal")
            na "The, um, defendant? That's... er... Mia Fey?"
            call bg_lawyer_support("chihiro court_angry")
            chi "Wrong, Wright. Look, I have to leave. I have to go home. I'm... I'm expecting a delivery."
            na "Aw, c'mon Chief. There's no need to be going so soon, is there?"
            chi "Listen, Wright! The defendant is the one on trial--your client! I mean, that's about as basic as you can get!"
            na "(I put my foot in it this time! I've got to relax!)"
            call bg_judge("judge normal")
            jdg "Sorry, I couldn't hear your answer. I'll ask once more:"
            jump choice_1_1_1
    call bg_judge("judge normal")
    jdg "Correct."
    jdg "Just keep your wits about you and you'll do fine."
    jdg "Next question: This is a murder trial. Tell me, what's the victim's name?"
    call bg_lawyer("naruhodo normal")
    na "(Whew, I know this one! Glad I read the case report cover to cover so many times.)"
    show naruhodo thinking as img_lawyer
    na "(It's... wait...{w=0.3}{nw}"
    show naruhodo nervous as img_lawyer
    extend " Uh-oh!)"
    show naruhodo surprising as img_lawyer
    $ renpy.pause(1.0)
    show naruhodo nervous as img_lawyer
    na "(No... no way! I forgot! I'm drawing a total blank here!)"
    call bg_lawyer_support("chihiro court_angry")
    chi "Phoenix! Are you absolutely SURE you're up to this?"
    chi "You don't even know the victim's name!?"
    na "Oh, the victim! O-Of course I know the victim's name!"
    na "I, um, just forgot.\n...Temporarily."
    chi "I think I feel a migraine coming on."
    show chihiro court_normal as img_lawyer_support
    chi "Look, the victim's name is listed in the Court Record."
    chi "Just press \[the R Button / Tab\] to check it at any time, okay?"
    chi "Remember to check it often.\nDo it for me, please.\nI'm begging you."
    call bg_judge("judge normal")
    menu choice_1_1_2:
        jdg "Mr. Wright.\nWho is the victim in this case?"
        "Mia Fey":
            call bg_judge("judge normal")
            jdg "Sorry, I couldn't hear your answer. I'll ask once more:"
            jump choice_1_1_2
        "Cinder Block":
            call bg_judge("judge normal")
            jdg "Sorry, I couldn't hear your answer. I'll ask once more:"
            jump choice_1_1_2
        "Cindy Stone":
            call bg_lawyer("naruhodo normal")
            na "Um... the victim's name is Cindy Stone."
    call bg_judge("judge normal")
    jdg "Correct."
    jdg "Now, tell me, what was the cause of death?"
    menu choice_1_1_3:
        jdg "She died because she was...?"
        "Poisoned":
            call bg_judge("judge normal")
            jdg "Sorry, I couldn't hear your answer. I'll ask once more:"
            jump choice_1_1_3
        "Hit with a blunt object":
            call bg_lawyer("naruhodo normal")
            na "She was struck once, by a blunt object."
        "Strangled":
            call bg_judge("judge normal")
            jdg "Sorry, I couldn't hear your answer. I'll ask once more:"
            jump choice_1_1_3
    call bg_judge("judge normal")
    jdg "Correct."
    jdg "You've answered all my questions. I see no reason why we shouldn't proceed."
    jdg "You seem much more relaxed, Mr. Wright. Good for you."
    call bg_lawyer("naruhodo normal")
    na "Thank you, Your Honor.\n{w=0.3}{nw}"
    show naruhodo nervous as img_lawyer
    extend "(Because I don't FEEL relaxed, that's for sure.)"
    call bg_judge("judge normal")
    jdg "Well, then..."
    jdg "First, a question for the prosecution. Mr. Payne?"
    call bg_prosecutor("ouch normal")
    ouch "Yes, Your Honor?"
    call bg_judge("judge normal")
    jdg "As Mr. Wright just told us, the victim was struck with a blunt object."
    jdg "Would you explain to the court just what that \"object\" was?"
    call bg_prosecutor("ouch normal")
    ouch "The murder weapon was this statue of \"The Thinker.\""
    ouch "It was found lying on the floor, next to the victim."
    call bg_judge("judge normal")
    jdg "I see... The court accepts it into evidence."

    $ inventory.add_item(thinker)
    "Statue added to the Court Record."

    call bg_lawyer_support("chihiro court_normal")
    chi "Wright..."
    chi "Be sure to pay attention to any evidence added during the trial."
    chi "That evidence is the only ammunition you have in court."
    chi "Use \[the R Button / Tab\] to check the Court Record frequently."
    call bg_gavel
    call bg_judge("judge normal")
    jdg "Mr. Payne, the prosecution may call its first witness."
    call bg_prosecutor("ouch normal")
    ouch "The prosecution calls the defendant, Mr. Butz, to the stand."
    call bg_lawyer_support("chihiro court_normal")
    na "Um, Chief, what do I do now?"
    chi "Pay attention. You don't want to miss any information that might help your client's case."
    chi "You'll get your chance to respond to the prosecution later, so be ready!"
    chi "Let's just hope he doesn't say anything... unfortunate."
    na "(Uh oh, Larry gets excited easily... This could be bad.)"
    scene black
    with Dissolve(1.0)
#**************************************
label gs1_1_4:
    call bg_witness("yahari court_normal")
    with Dissolve(1.0)
    $ renpy.pause(2.0)

    call bg_prosecutor("ouch normal")
    ouch "Ahem."
    ouch "Mr. Butz. Is it not true that the victim had recently dumped you?"
    call bg_witness("yahari court_nervous")
    $ renpy.pause(0.5)
    show yahari court_angry as img_witness
    $ renpy.pause(1.0)
    show yahari court_nervous as img_witness
    yah "Hey, watch it buddy!"
    yah "We were great together!\nWe were Romeo and Juliet, Cleopatra and Mark Anthony!"
    call bg_lawyer("naruhodo surprising")
    $ renpy.pause(1.0)
    show naruhodo nervous as img_lawyer
    na "(Um... didn't they all die?)"
    call bg_witness("yahari court_normal")
    yah "Hey, watch it buddy!"
    yah "I wasn't dumped! She just wasn't taking my phone calls. Or seeing me... Ever."
    show yahari court_angry as img_witness
    $ renpy.pause(1.0)
    show yahari court_nervous as img_witness
    yah "WHAT'S IT TO YOU, ANYWAY!?"
    call bg_prosecutor("ouch normal")
    ouch "Mr. Butz, what you describe is generally what we mean by \"dumped.\""
    ouch "In fact, she had completely abandoned you...{w=0.3} and was seeing other men!"
    ouch "She had just returned from overseas with one of them the day before the murder!"
    call bg_witness("yahari court_nervous")
    $ renpy.pause(0.5)
    show yahari court_angry as img_witness
    $ renpy.pause(1.0)
    show yahari court_nervous as img_witness
    yah "Whaddya mean, \"one of them\"!?"
    yah "Lies! All of it, lies!\nI don't believe a word of it!"
    call bg_prosecutor("ouch normal")
    ouch "Your Honor, the victim's passport."
    ouch "According to this, she was in Paris until the day before she died."

    $ inventory.add_item(passport)
    "Passport added to the Court Record."

    call bg_judge("judge normal")
    jdg "Hmm... Indeed, she appears to have returned the day before the murder."
    call bg_witness("yahari court_nervous")
    yah "Dude... no way..."
    call bg_prosecutor("ouch normal")
    ouch "The victim was a model, but did not have a large income."
    ouch "It appears that she had several \"Sugar Daddies.\""
    call bg_witness("yahari court_nervous")
    yah "Daddies?\nSugar?"
    call bg_prosecutor("ouch normal")
    ouch "Yes. Older men, who gave her money and gifts."
    ouch "She took their money and used it to support her lifestyle."
    call bg_witness("yahari court_nervous")
    yah "Duuude!"
    call bg_prosecutor("ouch normal")
    ouch "We can clearly see what kind of woman this Ms. Stone was."
    ouch "Tell me, Mr. Butz, what do you think of her now?"
    call bg_lawyer_support("chihiro court_normal")
    chi "Wright..."
    chi "I don't think you want him to answer that question."
    call bg_witness("yahari court_nervous")
    na "(Yeah... Larry has a way of running his mouth in all the wrong directions.)"
    menu choice_1_1_4:
        na "(Should I...?)"
        "Wait and see what happens":
            call bg_lawyer("naruhodo normal")
            na "(Might be better not to get involved in this one...)"
            call bg_prosecutor("ouch normal")
            ouch "Well, Mr. Butz?"
            call bg_witness("yahari court_nervous")
            $ renpy.pause(0.5)
            show yahari court_angry as img_witness
            $ renpy.pause(1.0)
            show yahari court_nervous as img_witness
            yah "Dude, no way! That cheatin' she-dog!"
        "Stop him from answering":
            call bg_lawyer("naruhodo smashing")
            na "My client had no idea the victim was seeing other men!"
            show naruhodo protesting as img_lawyer
            na "That question is irrelevant to this case!"
            call bg_prosecutor("ouch nervous")
            ouch "Oof! *wince*"
            call bg_witness("yahari court_nervous")
            $ renpy.pause(0.5)
            show yahari court_angry as img_witness
            $ renpy.pause(1.0)
            show yahari court_nervous as img_witness
            yah "Dude! Nick!\nWhaddya mean, \"irrelevant\"!?"
            show yahari court_normal as img_witness
            yah "That cheatin' she-dog!"
    show yahari court_nervous as img_witness
    $ renpy.pause(0.5)
    show yahari court_angry as img_witness
    $ renpy.pause(1.0)
    show yahari court_nervous as img_witness
    yah "I'm gonna die. I'm just gonna drop dead!"
    scene bg_court
    yah "Yeah, and when I meet her in the afterlife..."
    yah "I'm going to get to the bottom of this!"
    call bg_gavel
    call bg_judge("judge normal")
    jdg "Let's continue with the trial, shall we?"
    call bg_prosecutor("ouch normal")
    ouch "I believe the accused's motive is clear to everyone."
    call bg_judge("judge normal")
    jdg "Yes, quite."
    call bg_lawyer("naruhodo nervous")
    na "(Oh boy. This is so not looking good.)"
    call bg_prosecutor("ouch normal")
    ouch "Next question!"
    ouch "You went to the victim's apartment on the day of the murder, did you not?"
    call bg_witness("yahari court_nervous")
    yah "Gulp!"
    call bg_prosecutor("ouch normal")
    ouch "Well, did you, or did you not?"
    call bg_witness("yahari court_normal")
    yah "Heh? Heh heh. Well, maybe I did, and maybe I didn't!"
    call bg_lawyer("naruhodo nervous")
    menu choice_1_1_5:
        na "(Uh oh. He went. What do I do?)"
        "Have him answer honestly":
            show naruhodo normal as img_lawyer
            na "(I know! I'll send him a signal...)"
            show naruhodo smashing as img_lawyer
            na "(TELL{w=0.5}{nw}"
            show naruhodo thinking as img_lawyer
            extend " THE{w=0.5}{nw}"
            show naruhodo protesting as img_lawyer
            extend " TRUTH)"
            call bg_witness("yahari court_normal")
            yah "Er... Yeah! Yeah! I was there! I went!"
            scene bg_court
            $ renpy.pause(1.0)
            call bg_gavel
            call bg_judge("judge normal")
            jdg "Order!"
            jdg "Well, Mr. Butz?"
            call bg_witness("yahari court_normal")
            yah "Dude, chill!"
            yah "She wasn't home, man... So, like, I didn't see her."
            show objection at center, shake
            $ renpy.pause(1.0)
            hide objection
            call bg_prosecutor("ouch normal")
            ouch "Your Honor, the defendant is lying."
            call bg_judge("judge normal")
            jdg "Lying?"
            call bg_prosecutor("ouch normal")
            ouch "The prosecution would like to call a witness who can prove Mr. Butz is lying."
        "Stop him from answering":
            na "(I know! I'll send him a signal...)"
            na "(LIE LIKE A DOG)"
            yah "Um, well, see, it's like this: I don't remember."
            ouch "You \"don't remember\"? Well then, we'll just have to remind you!"
            na "(I got a bad feeling about this...)"
            ouch "We have a witness that can prove he DID go to the victim's apartment that day!"
    call bg_judge("judge normal")
    jdg "Well, that simplifies matters.\nWho is your witness?"
    call bg_prosecutor("ouch normal")
    ouch "The man who found the victim's body."
    ouch "Just before making the gruesome discovery..."
    call bg_witness("yahari court_nervous")
    ouch "He saw the defendant fleeing the scene of the crime!"
    scene bg_court
    $ renpy.pause(1.0)
    # 망치 3회 출력 필요
    call bg_gavel
    call bg_judge("judge normal")
    jdg "Order! Order in the court!"
    jdg "Mr. Payne, the prosecution may call its witness."
    call bg_prosecutor("ouch normal")
    ouch "Yes, Your Honor."
    call bg_lawyer("naruhodo nervous")
    na "(This is bad...)"
    call bg_prosecutor("ouch normal")
    ouch "On the day of the murder, my witness was selling newspapers at the victim's building."
    ouch "Please bring Mr. Frank Sahwit to the stand!"
    scene black
    with Dissolve(1.0)
#**************************************
label gs1_1_5:
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    $ renpy.pause(2.0)

    call bg_prosecutor("ouch normal")
    ouch "Mr. Sahwit, you sell newspaper subscriptions, is this correct?"
    call bg_witness("yamano normal")
    yamn "Oh, oh yes!\nNewspapers, yes!"
    call bg_judge("judge normal")
    jdg "Mr. Sahwit, you may proceed with your testimony."
    jdg "Please tell the court what you saw on the day of the murder."
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    "Witness's Account"
    $ set_testifying(1)
    call gs1_1_account_1
    scene black
    with Dissolve(1.0)
    $ set_testifying(0)
#**************************************
    call bg_judge("judge normal")
    jdg "Hmm..."
    call bg_lawyer("naruhodo smashing")
    na "(Larry! Why didn't you tell the truth?)"
    show naruhodo nervous as img_lawyer
    na "(I can't defend you against a testimony like that!)"
    call bg_judge("judge normal")
    jdg "Incidentally, why wasn't the phone in the victim's apartment working?"
    call bg_prosecutor("ouch normal")
    ouch "Your Honor, at the time of the murder, there was a blackout in the building."
    call bg_judge("judge normal")
    jdg "Aren't phones supposed to work during a blackout?"
    call bg_prosecutor("ouch normal")
    ouch "Yes, Your Honor..."
    ouch "However, some cordless phones do not function normally."
    scene bg02b
    ouch "The phone that Mr. Sahwit used was one of those."
    call bg_prosecutor("ouch normal")
    ouch "Your Honor..."
    ouch "I have a record of the blackout, for your perusal."

    $ inventory.add_item(borecord)
    "Blackout Record added to the Court Record."

    call bg_judge("judge normal")
    jdg "Now, Mr. Wright..."
    call bg_lawyer("naruhodo normal")
    na "Yes!\nEr... yes, Your Honor?"
    call bg_judge("judge normal")
    jdg "You may begin your cross-examination."
    call bg_lawyer("naruhodo thinking")
    na "C-Cross-examination, Your Honor?"
    call bg_lawyer_support("chihiro court_normal")
    chi "Alright, Wright, this is it. The real deal!"
    na "Uh... what exactly am I supposed to do?"
    chi "Why, you expose the lies in the testimony the witness just gave!"
    na "Lies! What?! He was lying!?"
    chi "Your client is innocent, right?"
    chi "Then that witness must have lied in his testimony!"
    chi "Or is your client really... guilty?"
    na "!!!{w=0.3} How do I prove he's not?"
    chi "You hold the key! It's in the evidence!"
    chi "Compare the witness's testimony to the evidence at hand."
    chi "There's bound to be a contradiction in there!"
    chi "First, find contradictions between the Court Record and the witness's testimony."
    chi "Then, once you've found the contradicting evidence..."
    chi "present it and rub it in the witness's face!"
    na "Um... okay."
    chi "Open the Court Record with \[the R Button / Tab\], then point out contradictions in the testimony!"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    "Witness's Account"
label gs1_1_6:
    $ set_testifying(2)
    $ set_interrogation_var(True, True)
    call gs1_1_account_1
    $ set_interrogation_var(False, False)
    call bg_lawyer_support("chihiro court_normal")
    chi "That's all of it."
    chi "There must be a contradiction in there somewhere."
    chi "Examine the Court Record with \[the R Button / Tab\] if something strikes you as being suspicious."
    chi "Then, find the evidence that contradicts his testimony, and present it to the court!"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    jump gs1_1_6
label gs1_1_7:
    $ set_testifying(0)
    call bg_lawyer("naruhodo protesting")
    na "You found the body at 1:00 PM.{w=0.3}{nw}"
    show naruhodo normal as img_lawyer
    extend " You're sure?"
    call bg_witness("yamano normal")
    yamn "Yes. It was 1:00 PM, for certain."
    call bg_lawyer("naruhodo smashing")
    $ renpy.pause(1.0)
    na "Frankly,{w=0.3}{nw}"
    show naruhodo normal as img_lawyer
    extend " I find that hard to believe!"
    show naruhodo checking as img_lawyer
    na "Your statement directly contradicts the autopsy report."
    na "The autopsy notes the time of death at sometime after 4PM."
    na "There was nobody to... er...\n{w=0.3}{nw}"
    show naruhodo normal as img_lawyer
    extend " no \"body\" to find at 1:00 PM!"
    show naruhodo confident as img_lawyer
    na "How do you explain this three-hour gap?"
    call bg_witness("yamano normal")
    yamn "!!!"
    yamn "Oh, that! Oh, er..."
    show objection at center, shake
    $ renpy.pause(1.0)
    hide objection
    call bg_prosecutor("ouch nervous")
    ouch "This is trivial! The witness merely forgot the time!"
    call bg_judge("judge normal")
    jdg "After his testimony, I find that hard to believe."
    jdg "Mr. Sahwit..."
    jdg "Why were you so certain that you found the body at 1:00 PM?"
    call bg_witness("yamano normal")
    yamn "I... er... well, I... Gee, that's a really good question!"
    call bg_lawyer_support("chihiro court_normal")
    chi "Great job, Wright! Way to put him on the spot!"
    chi "That's all you have to do: point out contradictions!"
    chi "Lies always beget more lies!"
    chi "See through one, and their whole story falls apart!"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    yamn "Wait! I remember now!"
    call bg_judge("judge normal")
    jdg "Would you care to give your testimony again?"
    scene black
    with Dissolve(1.0)
#**************************************
label gs1_1_8:
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    "The Time of Discovery"
    $ set_testifying(1)
    call gs1_1_account_2
    scene black
    with Dissolve(1.0)
    $ set_testifying(0)
#**************************************
    call bg_judge("judge normal")
    jdg "Hmm... I see. You heard a voice saying the time on a taped program."
    jdg "Mr. Wright, you may cross-examine the witness."
    scene black
    with Dissolve(1.0)
    call bg_lawyer_support("chihiro court_normal")
    with Dissolve(1.0)
    chi "Wright!"
    chi "You know what to do!"
    na "I've got this one."
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    "Witness's Account"
label gs1_1_9:
    $ set_testifying(2)
    $ set_interrogation_var(True, True)
    call gs1_1_account_2
    $ set_interrogation_var(False, False)
    call bg_lawyer_support("chihiro court_normal")
    chi "Notice anything suspicious?"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    jump gs1_1_9
label gs1_1_10:
    $ set_testifying(0)
    call bg_lawyer("naruhodo normal")
    na "Hold it right there!"
    na "The prosecution has said there was a blackout at the time of the discovery! And this record proves it!"
    call bg_witness("yamano normal")
    yamn "...!"
    call bg_lawyer("naruhodo normal")
    na "You couldn't have heard a television... or a video!"
    call bg_witness("yamano normal")
    yamn "Gah!!! I... well... urk!"
    call bg_judge("judge normal")
    jdg "The defense has a point. Do you have an explanation for this, Mr. Sahwit?"
    call bg_witness("yamano normal")
    yamn "No, I... I find it quite puzzling myself! Quite! ... Aah! W-wait! I remember now!"
    call bg_judge("judge normal")
    jdg "Mr. Sahwit? The court would prefer to hear an accurate testimony from the very beginning. These constant corrections are harming your credibility. That, and you seem rather... distraught."
    call bg_witness("yamano normal")
    yamn "...! M-my apologies, Your Honor! It... er, it must have been the shock of finding the body!"
    call bg_judge("judge normal")
    jdg "Very well, Mr. Sahwit. Let's hear your testimony once more please."
    scene black
    with Dissolve(1.0)
#**************************************
label gs1_1_11:
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    "The Time of Discovery"
    call gs1_1_account_3
    scene black
    with Dissolve(1.0)
#**************************************