label gs1_1_account_1:
    $ set_press("gs1_1_account_1_press_1")
    $ set_evidence("gs1_1_account_1_wrong")
    yamn "I was going door-to-door, selling subscriptions when I saw a man fleeing an apartment."
    $ set_press("gs1_1_account_1_press_2")
    if is_testifying == 1:
        scene bg02a
    yamn "I thought he must be in a hurry because he left the door half-open behind him."
    $ set_press("gs1_1_account_1_press_3")
    yamn "Thinking it strange, I looked inside the apartment."
    $ set_press("gs1_1_account_1_press_4")
    if is_testifying == 1:
        scene bg02b
    yamn "Then I saw her lying there... A woman... not moving... dead!"
    $ set_press("gs1_1_account_1_press_5")
    yamn "I quailed in fright and found myself unable to go inside."
    $ set_press("gs1_1_account_1_press_6")
    yamn "I thought to call the police immediately!"
    $ set_press("gs1_1_account_1_press_7")
    yamn "However, the phone in her apartment wasn't working."
    $ set_press("gs1_1_account_1_press_8")
    yamn "I went to a nearby park and found a public phone."
    $ set_press("gs1_1_account_1_press_9")
    $ set_evidence("gs1_1_7", 10)
    if is_testifying == 1:
        call bg_witness("yamano normal")
    yamn "I remember the time exactly: It was 1:00 PM."
    $ set_press("gs1_1_account_1_press_10")
    $ set_evidence("gs1_1_account_1_wrong")
    yamn "The man who ran was, without a doubt, the defendant sitting right over there."
    return
label gs1_1_account_1_press_1:
    call bg_lawyer("naruhodo normal")
    na "Isn't a man leaving an apartment a common sight? I find it odd you would take notice of him..."
    call bg_witness("yamano normal")
    yamn "Er... heh. I don't know. He just seemed strange to me, that's all. Like he was mad, and yet frightened at the same time. Just like... a criminal fleeing the scene of a crime!"
    call bg_lawyer("naruhodo normal")
    na "The defense requests that the witness refrain from conjecture!"
    call bg_prosecutor("ouch normal")
    ouch "Of course. What the witness means is that the man he saw looked suspicious. So, what happened next?"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_1_press_2:
    call bg_lawyer("naruhodo normal")
    na "Half-open... you say?"
    call bg_witness("yamano normal")
    yamn "Yes, yes, the door was open halfway. Yes. I watched for a moment, but no one came to close the door. \"That's odd, in a big city like this,\" I thought..."
    call bg_prosecutor("ouch normal")
    ouch "I see. And what happened next?"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_1_press_3:
    call bg_lawyer("naruhodo normal")
    na "What gave you the idea to do that?"
    call bg_witness("yamano normal")
    yamn "Well, the door was half-open, you see. Isn't it only human to want to... peek? We climb mountains because they are there! It's the same thing."
    call bg_prosecutor("ouch normal")
    ouch "Truer words have never been spoken! Anyone would look inside!"
    call bg_lawyer("naruhodo normal")
    na "(Hmm... why did Payne cut him off so quickly?)"
    call bg_prosecutor("ouch normal")
    ouch "So, you looked into the apartment. What happened then?"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_1_press_4:
    call bg_lawyer("naruhodo normal")
    na "Are you sure she was dead?"
    call bg_witness("yamano normal")
    yamn "W-Well, no, I guess I wasn't. But, she wasn't moving at all, and there was blood everywhere."
    call bg_lawyer("naruhodo normal")
    na "(I guess that would look fatal to anyone...)"
    na "Very well, what happened next?"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_1_press_5:
    call bg_lawyer("naruhodo normal")
    na "So, you didn't touch ANYTHING in the apartment?"
    call bg_witness("yamano normal")
    yamn "Um, yes. I mean no! Nothing."
    call bg_lawyer("naruhodo normal")
    na "Okay. What happened next?"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_1_press_6:
    call bg_lawyer("naruhodo normal")
    na "You \"thought\" to call the police? Does that mean you didn't actually call them!?"
    call bg_prosecutor("ouch normal")
    ouch "Please, please... Listen to the rest of the testimony. You thought to call the police... What happened next?"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_1_press_7:
    call bg_lawyer("naruhodo normal")
    na "The phone in her apartment wasn't working?"
    call bg_witness("yamano normal")
    yamn "Yes. I mean, no. No, it wasn't. Right."
    call bg_lawyer("naruhodo normal")
    na "But you said you didn't go into the apartment... or did you!?"
    call bg_witness("yamano normal")
    yamn "Oh, oh, that? I can explain that! There was a cordless phone on a shelf in the entranceway. I reached inside and tried using that to call..."
    call bg_prosecutor("ouch normal")
    ouch "And the phone wasn't working, correct? What happened next?"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_1_press_8:
    call bg_lawyer("naruhodo normal")
    na "Why use a public phone?"
    call bg_witness("yamano normal")
    yamn "Well, you see, I don't have a cell phone. And, being the middle of the afternoon, there was no answer at the nearby apartments."
    call bg_lawyer("naruhodo normal")
    na "Ah, right... what time did you call again?"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_1_press_9:
    call bg_lawyer("naruhodo normal")
    na "1:00 PM! Are you certain?"
    call bg_witness("yamano normal")
    yamn "Yes. Absolutely."
    call bg_lawyer("naruhodo normal")
    na "(Hmm... He seems really confident.)"
    call bg_lawyer_support("chihiro court_normal")
    chi "1:00 PM? Wright. Doesn't that seem strange to you? Present some evidence to contradict him!"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_1_press_10:
    call bg_lawyer("naruhodo normal")
    na "Are you absolutely, 100%% positive?"
    call bg_witness("yamano normal")
    yamn "Yes, it was him. No mistake about it."
    call bg_prosecutor("ouch normal")
    ouch "The witness says he's certain!"
    return
label gs1_1_account_1_wrong:
    call bg_lawyer("naruhodo normal")
    na "This evidence clearly reveals the contradiction in that statement, Your Honor!"
    call bg_judge("judge normal")
    jdg "How exactly are that evidence and the statement just now related...?"
    call bg_lawyer("naruhodo normal")
    na "The aren't, are they..."
    call bg_judge("judge normal")
    jdg "Not at all."
    jdg "Mr. Wright, please think the facts over before making accusations."
    na "(I don't think that won me any points with the judge...)"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
#**************************************
label gs1_1_account_2:
    $ set_press("gs1_1_account_2_press_1")
    $ set_evidence("gs1_1_10", 13)
    yamn "You see, when I found the body, I heard the time."
    $ set_press("gs1_1_account_2_press_2")
    if is_testifying == 1:
        scene bg02b
    yamn "There was a voice saying the time... It was probably coming from the television."
    $ set_press("gs1_1_account_2_press_3")
    yamn "Oh, but it was three hours off, wasn't it?"
    $ set_press("gs1_1_account_2_press_4")
    yamn "I guess the victim must have been watching a video of a taped program!"
    $ set_press("gs1_1_account_2_press_5")
    if is_testifying == 1:
        call bg_witness("yamano normal")
    yamn "That's why I thought it was 1:00 PM!"
    $ set_press("gs1_1_account_2_press_6")
    yamn "Terribly sorry about the misunderstanding..."
    return
label gs1_1_account_2_press_1:
    call bg_lawyer("naruhodo normal")
    na "You said \"heard\"... Not \"saw\"?"
    call bg_witness("yamano normal")
    yamn "Yes, heard. All I saw was the body lying there... I didn't think to look at anything else, least of all my watch."
    call bg_lawyer("naruhodo normal")
    na "Hmm... Isn't that a little strange? So you're saying you \"heard\" something. But if you were so shocked by the body, you wouldn't hear anything at all!"
    show objection at center, shake
    $ renpy.pause(1.0)
    hide objection
    call bg_prosecutor("ouch normal")
    ouch "The witness did say he actually heard the time. It's ludicrous to suggest he \"wouldn't hear anything\"!"
    call bg_judge("judge normal")
    jdg "Hmm... I have to agree with the prosecution. Witness, continue your testimony."
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_2_press_2:
    call bg_lawyer("naruhodo normal")
    na "Are you sure it was a television and not... a radio?"
    call bg_witness("yamano normal")
    yamn "Well, no, I guess it might have been a radio."
    call bg_prosecutor("ouch normal")
    ouch "Incidentally, there was no radio on the premises. There was only one large television."
    call bg_lawyer_support("chihiro court_normal")
    chi "Wright! I can't put my finger on it, but something about this seems fishy. Something about \"hearing\" the television..."
    call bg_prosecutor("ouch normal")
    ouch "The witness has testified. He heard the time."
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_2_press_3:
    call bg_lawyer("naruhodo normal")
    na "How do you explain the gap!"
    call bg_judge("judge normal")
    jdg "Well, witness? Can you explain this?"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_2_press_4:
    call bg_lawyer("naruhodo normal")
    na "A... video?"
    call bg_witness("yamano normal")
    yamn "Yes, that would explain why the time was wrong!"
    call bg_lawyer("naruhodo normal")
    na "True, true..."
    call bg_lawyer_support("chihiro court_normal")
    chi "Wright! I think the problem lies someplace else..."
    call bg_judge("judge normal")
    jdg "We're agreed that you heard the time at the scene, then."
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_2_press_5:
    call bg_lawyer("naruhodo normal")
    na "Are you sure the voice you heard said it was 1:00 PM?"
    call bg_witness("yamano normal")
    yamn "Yes, I can practically hear it now. It was quite clear."
    call bg_judge("judge normal")
    jdg "Mr. Payne, has the prosecution verified this testimony?"
    call bg_prosecutor("ouch normal")
    ouch "My apologies, Your Honor. I, too, have only just learned that the witness \"heard\" the time."
    call bg_witness("yamano normal")
    yamn "Oh, I'm really sorry. I only remembered it just now."
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
label gs1_1_account_2_press_6:
    call bg_lawyer("naruhodo normal")
    na "Well, you just watch it!"
    na "(Hmm... Not much point pressing him on that one, was there?)"
    scene black
    with Dissolve(1.0)
    call bg_witness("yamano normal")
    with Dissolve(1.0)
    return
#**************************************
label gs1_1_account_3:
    yamn "Actually, I didn't \"hear\" the time... I \"saw\" it!"
    yamn "There was a table clock in the apartment, wasn't there!"
    yamn "Yeah, the murder weapon! The killer used it to hit the victim!"
    yamn "That must have been what I saw."