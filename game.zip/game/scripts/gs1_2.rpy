label gs1_2_1:
    window hide None
    scene bg015a
    "Enough said."
#**************************************
label gs1_2_2:
    scene black
    with None
    "September 5, 9:08 PM\nFey & Co. Law Offices"

    $ current_position = "law_office"
    $ set_testifying(0)
    $ inventory.add_item(badge)
    $ inventory.add_item(chihiro)
    $ inventory_toggleable = True
    scene bg009
    na "Uh oh, I'm late."
    na "Huh, that's strange. The chief must have gone home already."
    na "She said her sister was coming over so we should all go out for dinner..."
    na "..."
    na "What's that smell...?"
    na "Blood...?"
    na "Mia!\n(Maybe she's in her office!)"
    $ current_examine_screen = "demo_background"
    call screen action_screen
#**************************************
screen move_location_label():
    modal True

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 10

        textbutton "Office" action [Hide("move_location_label"), Jump("gs1_2_3")]
#**************************************
screen demo_background():
    imagemap:
        ground "bg009"

        # hotspot (113, 173, 151, 122) action [SetVariable("demo_background_1_response", 1), Jump("demo_background_1_answer")]
        # hotspot (52, 124, 225, 108) clicked Jump("icecream") hovered ShowTransient("the_img", img="icecream.png") unhovered Hide("the_img")
        hotspot (0, 0, 1280, 720) action [Hide("demo_background"), Jump("gs1_2_2_examine1")]
        
        textbutton "Back" action [Hide("demo_background"), Show("action_screen")] xalign 0.5 yalign 0.95
#**************************************
label gs1_2_2_examine1:
    na "I smell blood... and that can't be good!"
    na "I have to check and see if Mia... the Chief's okay!"
    call screen demo_background
#**************************************
label gs1_2_3:
    scene black
    with Dissolve(1.0)
    scene bg000t
    with Dissolve(1.0)
    na "That smell... Blood!"
    q "..."
    q "*sob*"
    q "Sis..."
    na "(Someone's there!)"
    scene bg000:
        xpos -1280
        linear 1:
            xpos 0
    pause 1
    scene bg00a with flash
    na "...!"
    na "Chief? Chief...?"
    na "Chief!!!"
    scene black
    with Dissolve(1.0)
    scene bg000:
        xpos 0
    with Dissolve(1.0)
    show mayoi depressed at center
    with Dissolve(1.0)
    na "Who are you?"
    q "..."
    hide mayoi
    with Dissolve(1.0)
    scene black
    with Dissolve(1.0)
    na "(The strange girl dropped out cold. I left her lying on the office sofa.)"
    na "(I went back to the chief where she lay under the window.)"
    scene bg011
    with Dissolve(1.0)
    na "(Her body was still warm...)"
    na "(I could feel it when I held her shoulder.)"
    na "(Then, all too quickly, it began to fade...)"
    na "(Until finally she was cold.)"
    scene black
    with Dissolve(1.0)
    scene bg000:
        xpos 0
    with Dissolve(1.0)
    na "Chief..."
    $ current_examine_screen = "demo_background2"
    call screen action_screen
#**************************************
screen demo_background2():
    imagemap:
        ground "bg000" xpos current_pos
        hover "bg0001"

        hotspot (380, 590, 229, 112) action [Hide("demo_background2"), Jump("gs1_2_3_examine1")]
        hotspot (701, 397, 271, 141) action [Hide("demo_background2"), Jump("gs1_2_3_examine2")]

        hotspot (1974, 36, 160, 202) action [Hide("demo_background2"), Jump("gs1_2_3_examine3")]
        
        textbutton "Back" action [Hide("demo_background2"), Show("action_screen")] xalign 0.5 yalign 0.95
        if current_pos == 0:
            textbutton "Slide" action [SetVariable("current_pos", -1280)] xalign 0.48 yalign 0.5
        else:
            textbutton "Slide" action [SetVariable("current_pos", 0)] xalign 0.52 yalign 0.5
#**************************************
label gs1_2_3_examine1:
    na "It's encrusted with dried blood."
    na "How ironic that this became the murder weapon... again."
    call screen demo_background2
#**************************************
label gs1_2_3_examine2:
    na "Some shards of glass are scattered on the floor."
    na "They seem to be the remains of a glass light stand."
    call screen demo_background2
#**************************************
label gs1_2_3_examine3:
    na "Surprisingly, the chief was never good with machines."
    na "About all she used this PC for was e-mail. She picked up this ancient model at some garage sale for practically nothing."
    call screen demo_background2
#**************************************