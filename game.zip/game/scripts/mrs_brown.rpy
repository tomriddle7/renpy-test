﻿label mrs_brown:
    $ current_character = "scene_mrs_br"
    show wife behind office_parts
    if meet_mrs_br is True:
        jump choice_mrs_br_1
    else:
        with Dissolve(1.0)
    window hide
label scene_mrs_br_1:
    if meet_mrs_br is True:
        $ com_topic = ""
        show screen enterName
        # com_topic = renpy.input("What topic?")
        # jump continue
        $ ui.interact()
    else:
        $ meet_mrs_br = True
        hero "고인에 대한 얘기는 저도 뉴스틀 통해 들었습니다."
        mrs_br "네... 그 사고에 대한 소식은 한동안 인구에 회자되었으니까요."
        hero "이번 상담에 오시게 된 계기는 어떤 건가요?"
        mrs_br "경찰에서... 사고 이후 얘기하는 과정에서, 심리상담을 받아보라고 권하더라고요."
        hero "네. 우선 말씀드리고 싶은 건, 이 심리상담은 상담자님의 자의에 의해 진행되며, 본인이 원하지 않으시면 언제라도 중단하실 수 있다는 겁니다."
        hero "또, 여기서 말하는 내용들은 외부로 노출되지 않으며, 불가피하게 공개될 때는 비식별화 조치를 통해 내담자님의 개인 정보가 유출되지 않도록 조치를 취한다는 점을 말씀드립니다."
        mrs_br "그럼... 어떤 얘기부터 하는 게 좋을까요?"
        hero "일반적으로는 처음에 내담자님의 가족에 대한 얘기를 많이 해요. 처음에 얘기해도 가장 부담이 없고, 또 일반적이어서 다들 그렇게 하는 편이죠."
        mrs_br "네... 그러면 가족에 대한 얘기부터 시작해볼게요."
        jump scene_mrs_br_basic

label continue:
    $ com_topic = com_topic.strip()
    hide screen enterName
    if com_topic in ["학창", "학창시절"]:
        $ com_topic = current_character + "_school"
        call expression com_topic
    elif com_topic in ["대인관계"]:
        $ com_topic = current_character + "_friends"
        call expression com_topic
    elif com_topic in ["음주", "흡연", "술", "담배", "술담배"]:
        $ com_topic = current_character + "_alcohol"
        call expression com_topic
    elif com_topic in ["자살시도", "시도"]:
        $ com_topic = current_character + "_attempt"
        call expression com_topic
    elif com_topic in ["변화", "갑작스러운 변화"]:
        $ com_topic = current_character + "_change"
        call expression com_topic
    elif com_topic in ["스트레스"]:
        $ com_topic = current_character + "_stress"
        call expression com_topic
    else:
        hero "이 주제는 아니야... 다시 생각해보자."
        call screen comm_screen
label scene_mrs_br_basic:
    mrs_br "제 이름은 제레미 브랜트입니다. 앤더슨 브랜트의 동생이에요."
    mrs_br "저희 가족은 할머니와 형, 그리고 저로 되어있어요."
    mrs_br "부모님은 어렸을 때 일찍 이혼하셨고, 아버지는 늘 외지에서 일하고 있어서 저희는 할머니 손에서 자랐어요."
    mrs_br "몇 달에 한 번씩 아버지가 오실 때면 늘 술마시던 기억밖에 없어요. 그전부터 아버지는 어머니와 다투던 때가 많았는데, 생각해보면 그때문인지도 모르겠어요."
    mrs_br "10살도 채 되기 전에 아버지는 돌아가셨어요. 나중에서야 아버지가 간암이었다는 것을 알았죠."
    mrs_br "사실 별로 놀랄 일은 아니었어요. 집에서나 밖에서나 늘 술만 마시던 사람이었으니."
    mrs_br "하지만 그때는 어려서 아무 것도 모를 때라, 그저 아버지가 돌아가셨다는 것만 떠올라서 장례식 내내 울었던 기억이 나네요."
    hero "지금 하시는 말씀을 들어보면, 학창시절에도 힘드셨을 것 같네요."
    mrs_br "그러게요. 학창시절이라..."
    $ inventory.add_item(interview[1])
    
    $ current_cards.append(Evidence("앤더슨 브랜트", 800, 250))
    $ current_cards.append(Evidence("제레미 브랜트", 1050, 250))
    call screen comm_screen
label scene_mrs_br_friends:
    mrs_br "입사하고서 처음에는 주말마다 회사 얘기를 했어요. 오늘은 선배가 밥을 사줬다, 동기랑 뭐 했다. 이런 얘기를 종종 했는데..."
    mrs_br "어느 순간분터는 회사 얘기를 아예 안 꺼냈어요."
    mrs_br "메인 아나운서가 된 이후로는 주말에도 방에만 있고 사람은 만나지도 않았어요."
    $ inventory.add_item(interview[4])
    call screen comm_screen
label scene_mrs_br_school:
    mrs_br "형은 학창시절에 늘 밝고 친절해서 인기가 많았어요. 선생님들도 책임감이 있고 추진력이 있다고 좋아했고요."
    mrs_br "대학 때는 과 대표를 맡아서 여러 사안들을 원만하게 처리했고, 대학교간 교류전에서 사회를 맡은 적도 있고요."
    mrs_br "친구들도 꽤 있어서 가끔 집에 놀러와서 자고 가기도 했어요."
    mrs_br "형은 늘 아나운서가 되고 싶어했어요. 그래서 KNN 아나운서 모집에 합격했을 떄는 정말 뛸 듯이 기뻐했어요. 그 날 밤새도록 둘이서 마주앉아서 맥주에 과자 펴놓고 마시던 기억이 생생한데..."
    $ inventory.add_item(interview[3])
    call screen comm_screen
label scene_mrs_br_alcohol:
    hero "생전에 술이나 담배를 많이 한다던가 하는 건 있었나요?"
    mrs_br "술담배요? 저희 형은 담배 같은 건 아예 안피우던 사람이었어요."
    mrs_br "술은... 대학시절 친구들이랑 마시긴 했었어요. 그때도 분위기 맞추기 위해 조금만 마셨지, 취할 정도로 마시는 건 한 번도 못 봤어요."
    mrs_br "그런데 방송국에 입사한 뒤로는 회식이다 뭐다 하면서 술 마시는 날이 늘었던 것 같아요."
    mrs_br "9시 뉴스 앵커 맡은 뒤로는 정말 술을 달고 살았어요."
    mrs_br "어떤 날은 밤새 술마시고 못일어나서 회사에 지각할 뻔한 적도 있었고요."
    hero "고인이 그정도로 심한 스트레스를 받은 이유를 아시나요?"
    $ inventory.add_item(interview[2])
    call screen comm_screen
label scene_mrs_br_stress:
    mrs_br "형의 유품을 정리하면서 알게된 건데... 직장에서 따돌림당하고 있더라고요."
    mrs_br "입사 3년차에 메인 뉴스 앵커를 맡게 되서 윗기수에서 잘난체한다고 안좋게 보인 모양이에요."
    mrs_br "그런데 방송국에 입사한 뒤로는 회식이다 뭐다 하면서 술 마시는 날이 늘었던 것 같아요."
    mrs_br "진행 끝나고 사무실로 불려가서 조인트 까이고 회의 자리에서 대놓고 질책받고..."
    mrs_br "퇴근하는 형 얼굴이 어둡긴 했지만 방송국 일이 힘들어서 그런 거라고만 생각했는데 지금 생각하니 그 때문인 것 같아요."
    $ inventory.add_item(interview[7])

    $ current_cards.append(Evidence("따돌림", 800, 350))
    $ current_cards.append(Evidence("이혼", 1050, 350))
    $ current_cards.append(Evidence("불치병", 800, 450))
    $ current_cards.append(Evidence("해고", 1050, 450))
    call screen comm_screen
label scene_mrs_br_attempt:
    mrs_br "이전 자살시도라..."
    mrs_br "이거는 세상에 알려진 얘기가 아닌데, 6개월 전에도 한 번 수면제 한 통을 그대로 들이키고 병원으로 실려간 적이 있어요."
    mrs_br "그때도 난리가 나서 할머니랑 저랑 병원에서 밤을 새면서 기다렸었는데..."
    mrs_br "그 때 병원에서 눈 뜬 형의 얼굴이 생각나요."
    mrs_br "눈 뜨자마자 제 얼굴 만지면서 '미안하다'고 하더라고요."
    mrs_br "그 때 형 손 붙잡고 하염없이 울었던 기억이 나요."
    mrs_br "그런 일도 있고 해서 다시 그런 일이 또 있을 거라고는 생각 못했는데..."
    "동생은 한동안 말을 잇지 못하고 흐느꼈다."
    mrs_br "병원에서 퇴원한 후에 회사에서 병가를 받아서 1주일 정도 집에서 쉬었어요."
    mrs_br "휴가 내내 기운없이 침대에 누워만 있는 모습을 보였지만 병원에서 막 퇴원했으니 당연한 거라고 생각했죠."
    mrs_br "식사도 거의 못해서 할머니가 차려놓은 저녁이나 겨우 먹는 정도였어요."
    mrs_br "그렇게 있다가 출근도 하고, 다시 일상으로 돌아가서 이제 괜찮아졌나 싶었는데..."
    $ inventory.add_item(interview[5])
    call screen comm_screen
label scene_mrs_br_change:
    mrs_br "사망 전에 특별히 다른 점이요?"
    mrs_br "그 전주에 형이 갑자기 캠핑을 가자고 하더라고요."
    mrs_br "대학 때는 종종 같이 캠핑 가곤 했었어도 졸업한 이후로는 각자 일로 바빠서 시들했는데 느닷없이 그런 얘기를 하니 뜻밖이었죠."
    mrs_br "그런데 그 다음주에 입사 면접이 잡혀있어서 다음에 가자고 얘기했거든요."
    mrs_br "그리고 그 다음주에...(오열)"
    mrs_br "지금도 캠핑 같이 가자는 말에 건성으로 대답해 준 게 마음에 걸려요."
    mrs_br "아, 그러고보니 며칠 전에는 청소를 하더라고요."
    mrs_br "메인 앵커 된 뒤로는 방 정리도 안하고 옷도 늘 바닥에 버려두다시피해서 엉망진창이었는데."
    mrs_br "제가 무슨 일이냐고 물어봐도 그냥 기분전환이라고만 했어요."
    mrs_br "그러고는 안쓴지 오래 됐다며 자기 노트북도 주고..."
    mrs_br "지금 생각해보면 그 모든게 주변정리였던 것 같아요."
    $ inventory.add_item(interview[6])
    call screen comm_screen