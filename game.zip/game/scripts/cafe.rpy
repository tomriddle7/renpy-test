﻿label cafe:
    window hide
    window hide None
    $ current_position = "cafe"
    scene cafe
    if come_cafe is True:
        pass
    else:
        with Dissolve(3.0)
        $ come_cafe = True
    call screen action_screen