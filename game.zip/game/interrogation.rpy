# 전역 심문 인스턴스
# 0: None 1: Testimony 2: Examine
default is_testifying = 0
default is_interrogating = False
default is_presenting = False
default present_item_uid = 0
default jump_label_interrogate = ""
default jump_label_present = ""

screen interrogation_screen():
    zorder 100
    modal True
    
    add "images/etc00bu.png" size (720, 720) at center

# 심문 함수
init python:
    def set_press(label = ""):
        """추궁시 대화 설정 함수"""
        global jump_label_interrogate
        jump_label_interrogate = label
    def interrogate():
        """추궁 화면을 호출하는 함수"""
        global is_interrogating
        if is_interrogating and jump_label_present != "":
            renpy.call("hold_effect")
    def set_evidence(label = "", uid = 0):
        """증거 설정 함수"""
        global jump_label_present
        global present_item_uid
        jump_label_present = label
        present_item_uid = uid
    def present_evid():
        """증거를 제시하는 함수"""
        global is_presenting
        if is_presenting and jump_label_present != "":
            renpy.call("present_evid_effect")
    def set_interrogation_var(interrogation, present):
        global is_interrogating
        global is_presenting
        is_interrogating = interrogation
        is_presenting = present
    def set_testifying(testifying):
        global is_testifying
        is_testifying = testifying
        renpy.hide_screen("court_record")
        renpy.hide_screen("court_examine")
        if is_testifying == 0:
            renpy.show_screen("court_record")
        elif is_testifying == 2:
            renpy.show_screen("court_examine")

# 단축키 설정 (선택사항)
init python:
    config.keymap['interrogate_toggle'] = ['i', 'I']

# 인벤토리 단축키 바인딩
init:
    $ config.underlay.append(renpy.Keymap(interrogate_toggle=Function(interrogate)))